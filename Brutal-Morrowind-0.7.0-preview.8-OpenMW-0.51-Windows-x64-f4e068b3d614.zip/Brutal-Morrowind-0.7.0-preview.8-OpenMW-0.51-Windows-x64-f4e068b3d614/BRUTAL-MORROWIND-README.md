# Brutal Morrowind 0.7.0-preview.8

This blood update starts from the exact stable preview.2 source revision
`a76508441a8dd4a791a38cab140f04bf7c2a2323`. It does not include subsequent
experimental changes from other branches. Combat calculations are unchanged.

## Exterior receiver traversal fix after preview.7

Blood sprites could remain visible while the ground receiver query returned no
land triangles. Object roots are inserted before terrain in the game graph;
the snapshot's node limit could be spent before terrain was visited. Sorting
the already collected meshes afterwards did not repair that missing data.

Land and paged static receivers now have a dedicated bounded traversal before
the general object tree. Distant references are rejected against the query
before spending the nearby-node budget. Paged pavement below a terrain root
and unpaged floors/bridges remain receivers above the underlying land. The
existing triangle, particle and two-layer limits are retained. A rate-limited
log warning records exterior receiver-query failures and their world positions.

The regression reproduces zero captured ground vertices in preview.7 with
18,000 preceding distant references. Additional native EGL checks cover the
default TerrainGrid and distant QuadTreeWorld, using their actual chunk buffers
and draw/cull path, both depth modes and the original floor PNGs. They run the
whole receiver -> droplet -> decal -> framebuffer path and require visible
decal pixels after all flying particles have expired. The normal/reversed native
GL checks are registered when BRUTAL_TEST_NATIVE_GL is enabled. These synthetic
scenes are not a playtest with a user's Morrowind installation.

## Corrections after preview.6

Grounded wounds establish their shared puddle on the first emitted blood drop,
instead of first filling its footprint with a quarter-second of separate impact
decals. Deposits prefer an existing pool, including its fitted faces on curved
ground. Growing pools absorb fully contained details using a bounded union-of-
faces containment proof; holes and separate floors cannot be absorbed by radius
alone. The arbitrary eight-neighbor rejection is removed: actual overlap work
remains bounded, and no more than two blood layers cover a receiver point.
Receiver matching accounts for float precision at distant exterior coordinates,
where clipped narrow triangles previously escaped the overlap test.

Static surface snapshots are refreshed in their existing shared cache slots,
rather than appending duplicates that evict another bleeding body's receiver.
Nearby exterior cells in the same worldspace share snapshots. Unchanged snapshots
are reused for two seconds; the two-builds-per-frame limit remains, and a valid
old snapshot stays usable if that frame's refresh budget is exhausted. Explicit
movement, deletion and cell invalidation still invalidate affected receivers.

Ballistic sprite fountains no longer also spawn legacy NIF blood effects at
every wound pulse. The billboard vertices now use a local origin with a double-
precision transform, preserving their visibility at large exterior coordinates.
Fallback callers without a ballistic trail retain their original blood effect.
Blood amount, stain lifetime, the original wall/floor artwork and combat rules
retain their preview.6 settings.

Regression checks compare twelve bleeding wounds on three corpses on flat tiled
floors and curved, densely tessellated ground at distant world coordinates. They
sample the two-layer bound, substantial pool growth and comparable ground
coverage. The ten-corpse stress check rejects duplicate legacy NIF spawning, and
actual normal/reversed-Z GL checks render the billboards at exterior coordinates.
These checks do not substitute for an in-game FPS measurement with user assets.

## Pool overdraw and sprite droplets

Surface blood now has a maximum of two overlapping geometry layers on the same
receiver. New splats are clipped only where two existing stains already cover
the surface; uncovered areas and peripheral splashes remain possible. A spatial
hash finds nearby stains of any age without repeatedly scanning the full cache.
Overlapping stacks from older saves are compacted while preserving saved ages.

Repeated floor impacts feed one growing pool. Growth is projected again onto
the visible receiver mesh at most four times per second, up to a
96-unit radius. Dense native impacts are routed before triangle projection, so
redundant drops do not repeatedly tessellate the same floor. Texture identity is
preserved as the pool grows. The existing total stain and geometry caps remain.
Per update, native effects can project at most twelve new deposits and four pool
growths; eight bounded containment checks can absorb smaller covered stains.
Complex redundant deposits are rejected within a small geometry-work budget.
Uncovered holes remain eligible for new hits when a pool cannot grow. These
limits apply to live effects; loading retains a separate bounded compaction
path so a large save is not truncated by a single-frame emission budget.

Airborne droplets are camera-facing textured sprites, batched as four vertices
and six indices per drop instead of the previous 24-vertex volume. Their shared
alpha texture has transparent edges. The GPU orients the sprites for each
camera; trajectories, collision sweeps, lighting, fog and native shadows remain
active. There is no individual scene node or rigid body for each drop.

Exterior coverage has three additional corrections. Native terrain is collected
before paged decoration, and the bounded triangle scan is shared between meshes
so one large combined model cannot omit the ground. Pools probe up to 64 units
below resting wounds, covering gaps caused by uneven terrain. Render batches
use a local origin and a double-precision scene transform; the saved geometry
remains in world coordinates. This avoids losing much of a decal in the depth
buffer at large exterior coordinates and shallow viewing angles.

## World surfaces, lighting and stronger sprays

Preview.5 replaces physics collision receivers with a bounded snapshot of the
visible world meshes. Stains are clipped against their actual triangles: stair
treads remain separate surfaces and curved columns retain their shape. Hidden
parallel surfaces are rejected. Furniture and visible NIF geometry without a
collision mesh, including carpets, can receive blood. Actors, water, particles
and collision-only nodes are excluded from this surface snapshot.

Nearby blood effects share cached mesh/BVH snapshots, with at most two fresh
snapshots per rendered frame and a bounded sixteen-entry cache. Moving or
removed receivers invalidate only nearby snapshots. Each stain has a maximum
of 192 projected vertices, and the existing global geometry limit still applies.
Deposited blood remains world-space geometry; it does not follow moving doors
or inventory objects. Existing saved stains retain their surface-projected shape,
with redundant overlap clipped during loading; the corrected receiver projection
applies to new deposits.

Blood uses the scene's current ambient, sun and nearby point lights, with native
attenuation and fog. Native shader shadow libraries handle the sun's shadow
maps. Both stains and airborne droplets respond to lighting without a fixed
brightness floor. Burgundy pigment and stable per-stain shade variation remain.

The Blood amount slider increases launch speed and spread as well as emission.
At 300%, launch speed is 1.8 times and cone width 1.6 times their 100% values.
Droplets are wider and stretch along their velocity. Neck and major body cuts
produce stronger jets; longitudinal separation has six sources following the
moving cut faces. Droplets live up to three seconds so higher sprays can land.
The 192-droplet and eight-impact-projection per-trail budgets remain bounded,
and emission is shared fairly between wound sources.

## New blood decals and creature bleeding

Six user-provided PNGs from `splatterss.zip` replace the procedural surface
splats: four `wall` images and two `floor` images. The original RGBA files are
bundled unchanged. A shared bounded texture atlas preserves their transparency
and aspect ratios without allocating a drawable or shader per stain.

Upward surfaces choose floor artwork; walls choose wall artwork. A wall's
vertical texture axis follows world-up projected onto the surface, so drips
never rotate randomly or turn upside down. Floor artwork uses only its original
orientation or a 180-degree turn. Both groups may mirror horizontally; variants
and modest size variation are random. The visual seed is saved with each stain,
so loading a save does not reshuffle the artwork.

Blood amount defaults to 100% of a doubled baseline. At 100%, emission and the
existing pool-size response match the former 200% setting; 300% emits six times
the original preview.2 baseline, subject to the same particle/work limits. New
decal footprints are additionally 1.75 times larger in each direction. Blood
is tinted dark burgundy, with subtle per-stain brightness and shade differences
derived from the saved visual seed. Original PNGs remain unchanged. Existing
saved stains receive the new tint but keep their surface-projected geometry.

Stain lifetime defaults to 1200 seconds (20 minutes). Explicit existing user
settings retain their values: if preview.3 left Blood amount at 200%, set it to
100% under Esc > Settings > Physics to use the new baseline. The upper limit
remains 300%. Raising the lifetime does not remove the bounded cache or particle
budgets.

Organic creatures now bleed from physical health hits and emit a short fountain
on a new death, including creatures with no supported ragdoll profile. Loading
an already dead creature does not replay the fountain. Mechanical, spectral and
skeletal families are excluded from both ballistic and legacy sprite blood.
TES3 has no universal no-blood flag: identification uses canonical creature IDs,
their original IDs and mesh paths, not localized display names. Unusually named
custom models may require extending this classification.

The cache holds up to 32768 stains while retaining preview.2's aggregate geometry
budget of 1572864 vertices. New stamps use at most 192 vertices, dirty batches
are rebuilt in one cache pass, and pool merging examines a bounded recent window.
Hit/death sprays, droplets and intestinal physics retain explicit work budgets.

Preview.2 blood saves can be loaded. New blood records use version 2 to preserve
texture choices and the larger cache; preview.2 cannot read these new records.
Keep the preview.2 installation and a separate copy of its saves.

A modified OpenMW 0.51.0 Windows x64 runtime. This continues the working
Real Combat Ragdoll 0.6.0-preview.5 engine, retaining its physics controls,
enchantment handling, directional hit rules and one-second immediate-death window.

Extract the complete Windows ZIP into a new directory and run `openmw.exe`.
Morrowind data and the usual OpenMW configuration are required. The launcher and
editor are not included. Keep a separate copy of saves: this version adds saved
Brutal Morrowind wounds and blood records, which older engine builds cannot read.

## Fix for stalls after several dismemberments

Preview.2 fixes the rapidly increasing cost of accumulated gore. A full blood
cache now evicts its oldest entry without shifting the other 8191 records. Blood
uses persistent chunks of at most 128 stains; a new splat only updates affected
chunks, and drying/fading uses a shader clock without rebuilding the entire cache
ten times a second. Droplets and intestinal tubes retain their geometry/VBOs
across frames. Intestinal triangles share ring vertices instead of duplicating
them. Gore materials share their shader programs.

Legacy blood sprites rotate between wounds with at most two NIF particle systems
per pulse, rather than spawning another system at every end of every severed
joint. Ballistic blood still comes from every wound. Pool growth is sampled at
most four times per second per wound; at most eight droplet impacts per trail per
update project a stain. These bounds prevent a slow frame from
amplifying the next frame's blood work. Blood quantity, stain lifetime, existing
physical wounds, inventories and saved blood remain supported.

## Blood

Successful physical health hits on NPCs and organic creatures emit ballistic droplets. Severed wounds
continue to spray and drip for the configured status duration (ten seconds at
defaults). The exposed neck has a stronger, pulsing arterial fountain. Droplets
follow gravity, sweep against collision triangles and stop at walls/floors.
Each stain is clipped against visible receiver triangles, so a splat does not
float across a corner. Grounded wounds gradually form larger pools.
Wet blood darkens as it dries; stains fade during their last ten seconds.

Esc > Settings > Physics adds two English controls:

| Control | Minimum | Default | Maximum |
| --- | ---: | ---: | ---: |
| Blood amount | 0% (off) | 100% (doubled baseline) | 300% |
| Blood stain lifetime | 300 s | 1200 s (20 minutes) | 1800 s |

The amount multiplies the doubled baseline and changes actual droplet emission
and splat/pool size. Native blood
sprite size follows the same amount control. Stain lifetime is independent of
bleeding duration and corpse physics: freezing or looting the body does not erase
its floor/wall stains. Lifetime changes retain elapsed time. Ages stop while
paused, continue in other locations and are saved with the stain geometry and
cell ID. Returning to an unexpired cell restores its stains; interiors at the
same coordinates do not share them. Loading a save preserves remaining time.

Blood is batched in small chunks per cell. A global limit of 32768 stains (also
bounded by the aggregate geometry budget) evicts the oldest in
extreme battles; nearby pools merge. Short hit sprays are limited to 32, and
each bleeding corpse has at most 192 live droplets. These limits prevent
unbounded scene/physics growth. Stains are attached to the location, not to moving
doors or clutter. Blood particles themselves are transient across save/load.

## Intestines and new physical wounds

Horizontal waist separation now exposes two loops of intestines. They are smooth,
rounded pink/red tubes with folds, veins and wet highlights, driven by 36 small
Bullet capsules and linked joints. They collide with world geometry, fall out of
the abdomen and remain attached to the torso. Their physical pose and joints are
saved with the corpse. They use the corpse's existing active-body/time budget.

The existing dismemberment chance applies to the new outcomes: 30% by default,
adjustable from 0% to 100%. No extra independent roll changes that probability.

| Weapon and lethal physical contact | New result after a successful wound roll |
| --- | --- |
| Two-handed long blade or two-handed axe, descending chop into head/torso | Longitudinal separation |
| Two-handed hammer, chop/slash into torso | Torso and extremities tear apart |
| Existing heavy horizontal slash into torso/eligible arm | Existing waist cut, now with intestines |

Longitudinal cuts clip actual posed triangles, interpolating UVs/normals and
retaining clothing/armour textures. Each side has its own pelvis, torso and head
collision bodies; the right arm/leg remain articulated with the right half.
Depth-tested flesh closes the exposed surfaces. Intestines appear on this cut
and on hammer torso tearing too. Removing equipment while looting updates the
visible halves. Whole robes remain uncut; the underlying severed body is exposed.
No equipment or inventory entries are removed, duplicated or replaced.

`BluntTwoClose` is the native two-handed hammer class. Staves (`BluntTwoWide`),
one-handed maces, spears and short blades do not inherit torso tearing. A thrust
does not produce a physical longitudinal cut. A vertical arm/leg hit does not
invent a centre-line cut. Existing one-handed cuts, crossbow head bursts and
direct elemental enchanted wounds retain their rules. Strong direct elemental
presentation still takes precedence over the physical wound where applicable.
Magic deaths before one second retain the impact; later DOT does not replay it.

Previous saved corpses retain their wounds. New features apply to new hits and
kills; loading an older save does not randomly recut its existing bodies.

## Validation and limits

Automated checks exercise the real Bullet solver, skinned mesh snapshots,
clipping/seam UVs, independent half poses, intestinal joints, saved blood ages,
cell visibility, blood amount endpoints, doubled base emission, enlarged stain
footprints, stable burgundy tint variation and lifetime expiry. Actual EGL/OpenGL
tests cover blood/flesh under native normal/reversed-Z projection, inherited NPC
shaders/alpha testing, opaque wall occlusion and expiration. Windows CI also
builds the full runtime, runs component/native integration tests, starts the
installed executable with `--version`, and checks ZIP integrity.

The stall regression exercises ten concurrent waist/longitudinal/hammer deaths
at maximum blood, stable intestinal buffers, bounded legacy sprite spawning and
cleanup. It also fills and overflows all 32768 stain slots, verifies that idle
aging does not reupload geometry, restores a full saved cache and expires it.
Both GL depth modes draw a full cache with eight simultaneous blood trails.
In the same debug CPU-only ten-hammer-death benchmark, the tenth second fell from
129 ms/frame to approximately 25 ms/frame. This measures physics/effect updates,
not game FPS, and does not predict a particular Windows machine's performance.

These checks do not replace an in-game playtest with your Morrowind data.
Standard humanoid NPC body-part meshes are supported; custom whole-body meshes
and unusual skeletons need separate compatibility checks. Creatures retain their
existing ragdoll support, but do not receive these humanoid cuts or intestines.
