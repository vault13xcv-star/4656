# 1.1 Experimental 2 — validation note

The Windows engine compiled and its installed `--version` check passed.
All four physics/render/impact test groups and all 1402 component tests passed.
The native integration run passed 38 of 39 tests.

The remaining test,
`ItemPhysicsIntegration.NativeWeaponClassesAndAnimationKeysSelectOnlyEligibleWounds`,
still expected a two-handed hammer torso hit to detach the waist. Experimental 2
intentionally keeps the waist intact and randomly detaches 3–5 extremities.
The two assertion failures are for the two native two-handed blunt weapon types.
This is an obsolete test expectation, not an observed runtime failure. The new
3/4/5 selection, normal chance gate, limb physics, save/load and elemental blood
rules passed their dedicated tests, including memory/undefined-behavior checks.

The integration test source has been corrected. The Windows engine was **not
recompiled** to fix that expectation; its EXE, DLLs and every original archive
entry are byte-for-byte the compiled candidate. The original failed-test log
and `VALIDATION.txt` are retained for transparency. The corrected Windows
integration test executable was not rebuilt or rerun in this publication job.

`RELEASE-INFO.json` records both the binary source revision and the corresponding
source revision with the corrected test. All engine/resource sources are
identical between those revisions. Publication only adds this note and the
provenance record to the runtime ZIP. No in-game Morrowind playtest was available.
