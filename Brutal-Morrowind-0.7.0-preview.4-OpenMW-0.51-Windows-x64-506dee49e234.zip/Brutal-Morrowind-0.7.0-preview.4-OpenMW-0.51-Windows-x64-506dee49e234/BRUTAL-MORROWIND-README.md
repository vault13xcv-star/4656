# Brutal Morrowind 0.7.0-preview.4

This blood update starts from the exact stable preview.2 source revision
`a76508441a8dd4a791a38cab140f04bf7c2a2323`. It does not include subsequent
experimental changes from other branches. Combat calculations are unchanged.

## New blood decals and creature bleeding

Six user-provided PNGs from `splatterss.zip` replace the procedural surface
splats: four `wall` images and two `floor` images. The original RGBA files are
bundled unchanged. A shared bounded texture atlas preserves their transparency
and aspect ratios without allocating a drawable or shader per stain.

Upward surfaces choose floor artwork; walls choose wall artwork. A wall's
vertical texture axis follows world-up projected onto the surface, so drips
never rotate randomly or turn upside down. Floor artwork uses only its original
orientation or a 180-degree turn. Both groups may mirror horizontally; variants
and modest size variation are random. The visual seed is saved with each stain,
so loading a save does not reshuffle the artwork.

Blood amount defaults to 100% of a doubled baseline. At 100%, emission and the
existing pool-size response match the former 200% setting; 300% emits six times
the original preview.2 baseline, subject to the same particle/work limits. New
decal footprints are additionally 1.75 times larger in each direction. Blood
is tinted dark burgundy, with subtle per-stain brightness and shade differences
derived from the saved visual seed. Original PNGs remain unchanged. Existing
saved stains receive the new tint but keep their surface-projected geometry.

Stain lifetime defaults to 1200 seconds (20 minutes). Explicit existing user
settings retain their values: if preview.3 left Blood amount at 200%, set it to
100% under Esc > Settings > Physics to use the new baseline. The upper limit
remains 300%. Raising the lifetime does not remove the bounded cache or particle
budgets.

Organic creatures now bleed from physical health hits and emit a short fountain
on a new death, including creatures with no supported ragdoll profile. Loading
an already dead creature does not replay the fountain. Mechanical, spectral and
skeletal families are excluded from both ballistic and legacy sprite blood.
TES3 has no universal no-blood flag: identification uses canonical creature IDs,
their original IDs and mesh paths, not localized display names. Unusually named
custom models may require extending this classification.

The cache holds up to 32768 stains while retaining preview.2's aggregate geometry
budget of 1572864 vertices. New stamps use at most 24 vertices, dirty batches
are rebuilt in one cache pass, and pool merging examines a bounded recent window.
Hit/death sprays, droplets and intestinal physics retain explicit work budgets.

Preview.2 blood saves can be loaded. New blood records use version 2 to preserve
texture choices and the larger cache; preview.2 cannot read these new records.
Keep the preview.2 installation and a separate copy of its saves.

A modified OpenMW 0.51.0 Windows x64 runtime. This continues the working
Real Combat Ragdoll 0.6.0-preview.5 engine, retaining its physics controls,
enchantment handling, directional hit rules and one-second immediate-death window.

Extract the complete Windows ZIP into a new directory and run `openmw.exe`.
Morrowind data and the usual OpenMW configuration are required. The launcher and
editor are not included. Keep a separate copy of saves: this version adds saved
Brutal Morrowind wounds and blood records, which older engine builds cannot read.

## Fix for stalls after several dismemberments

Preview.2 fixes the rapidly increasing cost of accumulated gore. A full blood
cache now evicts its oldest entry without shifting the other 8191 records. Blood
uses persistent chunks of at most 128 stains; a new splat only updates affected
chunks, and drying/fading uses a shader clock without rebuilding the entire cache
ten times a second. Droplets and intestinal tubes retain their geometry/VBOs
across frames. Intestinal triangles share ring vertices instead of duplicating
them. Gore materials share their shader programs.

Legacy blood sprites rotate between wounds with at most two NIF particle systems
per pulse, rather than spawning another system at every end of every severed
joint. Ballistic blood still comes from every wound. Pool growth is sampled at
most four times per second per wound; at most eight droplet impacts per trail per
update project a splat perimeter. These bounds prevent a slow frame from
amplifying the next frame's blood work. Blood quantity, stain lifetime, existing
physical wounds, inventories and saved blood remain supported.

## Blood

Successful physical health hits on NPCs and organic creatures emit ballistic droplets. Severed wounds
continue to spray and drip for the configured status duration (ten seconds at
defaults). The exposed neck has a stronger, pulsing arterial fountain. Droplets
follow gravity, sweep against collision triangles and stop at walls/floors.
Each stain's perimeter is projected onto the contacted surface, so a splat does
not simply float across a corner. Grounded wounds gradually form larger pools.
Wet blood darkens as it dries; stains fade during their last ten seconds.

Esc > Settings > Physics adds two English controls:

| Control | Minimum | Default | Maximum |
| --- | ---: | ---: | ---: |
| Blood amount | 0% (off) | 100% (doubled baseline) | 300% |
| Blood stain lifetime | 300 s | 1200 s (20 minutes) | 1800 s |

The amount multiplies the doubled baseline and changes actual droplet emission
and splat/pool size. Native blood
sprite size follows the same amount control. Stain lifetime is independent of
bleeding duration and corpse physics: freezing or looting the body does not erase
its floor/wall stains. Lifetime changes retain elapsed time. Ages stop while
paused, continue in other locations and are saved with the stain geometry and
cell ID. Returning to an unexpired cell restores its stains; interiors at the
same coordinates do not share them. Loading a save preserves remaining time.

Blood is batched in small chunks per cell. A global limit of 32768 stains (also
bounded by the aggregate geometry budget) evicts the oldest in
extreme battles; nearby pools merge. Short hit sprays are limited to 32, and
each bleeding corpse has at most 192 live droplets. These limits prevent
unbounded scene/physics growth. Stains are attached to the location, not to moving
doors or clutter. Blood particles themselves are transient across save/load.

## Intestines and new physical wounds

Horizontal waist separation now exposes two loops of intestines. They are smooth,
rounded pink/red tubes with folds, veins and wet highlights, driven by 36 small
Bullet capsules and linked joints. They collide with world geometry, fall out of
the abdomen and remain attached to the torso. Their physical pose and joints are
saved with the corpse. They use the corpse's existing active-body/time budget.

The existing dismemberment chance applies to the new outcomes: 30% by default,
adjustable from 0% to 100%. No extra independent roll changes that probability.

| Weapon and lethal physical contact | New result after a successful wound roll |
| --- | --- |
| Two-handed long blade or two-handed axe, descending chop into head/torso | Longitudinal separation |
| Two-handed hammer, chop/slash into torso | Torso and extremities tear apart |
| Existing heavy horizontal slash into torso/eligible arm | Existing waist cut, now with intestines |

Longitudinal cuts clip actual posed triangles, interpolating UVs/normals and
retaining clothing/armour textures. Each side has its own pelvis, torso and head
collision bodies; the right arm/leg remain articulated with the right half.
Depth-tested flesh closes the exposed surfaces. Intestines appear on this cut
and on hammer torso tearing too. Removing equipment while looting updates the
visible halves. Whole robes remain uncut; the underlying severed body is exposed.
No equipment or inventory entries are removed, duplicated or replaced.

`BluntTwoClose` is the native two-handed hammer class. Staves (`BluntTwoWide`),
one-handed maces, spears and short blades do not inherit torso tearing. A thrust
does not produce a physical longitudinal cut. A vertical arm/leg hit does not
invent a centre-line cut. Existing one-handed cuts, crossbow head bursts and
direct elemental enchanted wounds retain their rules. Strong direct elemental
presentation still takes precedence over the physical wound where applicable.
Magic deaths before one second retain the impact; later DOT does not replay it.

Previous saved corpses retain their wounds. New features apply to new hits and
kills; loading an older save does not randomly recut its existing bodies.

## Validation and limits

Automated checks exercise the real Bullet solver, skinned mesh snapshots,
clipping/seam UVs, independent half poses, intestinal joints, saved blood ages,
cell visibility, blood amount endpoints, doubled base emission, enlarged stain
footprints, stable burgundy tint variation and lifetime expiry. Actual EGL/OpenGL
tests cover blood/flesh under native normal/reversed-Z projection, inherited NPC
shaders/alpha testing, opaque wall occlusion and expiration. Windows CI also
builds the full runtime, runs component/native integration tests, starts the
installed executable with `--version`, and checks ZIP integrity.

The stall regression exercises ten concurrent waist/longitudinal/hammer deaths
at maximum blood, stable intestinal buffers, bounded legacy sprite spawning and
cleanup. It also fills and overflows all 8192 stain slots, verifies that idle
aging does not reupload geometry, restores a full saved cache and expires it.
Both GL depth modes draw a full cache with eight simultaneous blood trails.
In the same debug CPU-only ten-hammer-death benchmark, the tenth second fell from
129 ms/frame to approximately 25 ms/frame. This measures physics/effect updates,
not game FPS, and does not predict a particular Windows machine's performance.

These checks do not replace an in-game playtest with your Morrowind data.
Standard humanoid NPC body-part meshes are supported; custom whole-body meshes
and unusual skeletons need separate compatibility checks. Creatures retain their
existing ragdoll support, but do not receive these humanoid cuts or intestines.
