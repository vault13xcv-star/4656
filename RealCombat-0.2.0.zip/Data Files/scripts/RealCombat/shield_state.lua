-- Simulation-time shield state. Kept independent of OpenMW for regression tests.
local M = {}

function M.new()
    local held, ready, progress, elapsed = false, false, 0, 0
    local function snapshot()
        return { held = held, ready = ready, progress = progress, elapsed = elapsed }
    end
    local function reset()
        held, ready, progress, elapsed = false, false, 0, 0
    end
    local function update(dt, requested, raiseSeconds)
        if not requested then
            reset()
            return snapshot()
        end
        held = true
        dt = math.max(0, dt)
        if ready then
            elapsed = elapsed + dt
        else
            local duration = math.max(0.001, raiseSeconds)
            local remaining = (1 - progress) * duration
            if dt + 1e-9 >= remaining then
                progress, ready = 1, true
                elapsed = math.max(0, dt - remaining)
            else
                progress = progress + dt / duration
            end
        end
        return snapshot()
    end
    return { update = update, reset = reset, snapshot = snapshot }
end

return M
