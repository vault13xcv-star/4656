local types = require('openmw.types')
local config = require('scripts.RealCombat.config')
local state = require('scripts.RealCombat.attack_state')
local balance = require('scripts.RealCombat.balance')
local remainders = {}

local function ownsItem(actor, item)
    for _, candidate in ipairs(types.Actor.inventory(actor):getAll()) do
        if candidate == item then return true end
    end
    return false
end

local function correctWeaponWear(data)
    if not config.enabled or not data.item or not data.item:isValid()
        or not data.actor or not data.actor:isValid() then return end
    local item, actor = data.item, data.actor
    if not types.Weapon.objectIsInstance(item) then return end
    -- Ignore dropped/transferred weapons: do not repair somebody else's item.
    if not ownsItem(actor, item) then return end
    local itemData = types.Item.itemData(item)
    local current = itemData.condition
    local nextCondition, carry = state.correctWear(
        data.before, current, data.nativeWear, data.multiplier, remainders[item.id] or 0)
    remainders[item.id] = carry
    nextCondition = math.min(types.Weapon.record(item).health, nextCondition)
    itemData.condition = nextCondition
    if nextCondition <= 0 then
        actor:sendEvent('Unequip', {item = item})
    elseif current <= 0 then
        -- C++ may already have unequipped a weapon which this mod would not
        -- have broken. Restore only an empty hand, never replace a new choice.
        actor:sendEvent('RC_RestoreWeapon', {item = item})
    end
end

local function parryWear(data)
    local actor, item = data.actor, data.item
    if not actor or not actor:isValid() then return end
    local loss = 0
    if config.enabled and config.parry.enabled and item and item:isValid()
        and types.Weapon.objectIsInstance(item) and ownsItem(actor, item) then
        -- A parry has no native weapon-wear debit to reimburse. Debit its full
        -- cost, carrying fractional points in the SAME account as attack wear.
        local whole, carry = balance.wearCost(data.baseWear, data.multiplier, remainders[item.id] or 0)
        local itemData = types.Item.itemData(item)
        remainders[item.id] = carry
        loss = math.min(itemData.condition, whole)
        itemData.condition = math.max(0, itemData.condition - whole)
        if itemData.condition <= 0 then actor:sendEvent('Unequip', {item = item}) end
    end
    -- Acknowledge even rejected/transferred items so local reservations do not
    -- linger. A parry never sends RC_RestoreWeapon or repairs a broken weapon.
    actor:sendEvent('RC_ParryWearApplied', {item = item, requestId = data.requestId, loss = loss})
end

return {
    eventHandlers = { RC_CorrectWeaponWear = correctWeaponWear, RC_ParryWear = parryWear },
    engineHandlers = {
        onSave = function() return {version = 1, remainders = remainders} end,
        onLoad = function(data)
            remainders = data and data.remainders or {}
        end,
    },
}
