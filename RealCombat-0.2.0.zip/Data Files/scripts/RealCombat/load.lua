local content = require('openmw.content')
local config = require('scripts.RealCombat.config')
require('scripts.RealCombat.balance').validate(config)

-- A named, removable ability owns our accuracy contribution. Never overwrite a
-- shared magic-effect magnitude or alter the player's actual weapon skill.
content.spells.records.rc_melee_accuracy = {
    name = 'Real Combat: melee contact',
    type = content.spells.TYPE.Ability,
    cost = 0,
    effects = {{
        id = 'fortifyattack', range = content.RANGE.Self,
        magnitudeMin = config.accuracy.bonus,
        magnitudeMax = config.accuracy.bonus,
        duration = 0, area = 0,
    }},
}

if config.enabled and config.shield.enabled then
    -- C++ resolves random blocking before Lua receives Hit. Preserve its bounds
    -- for the NPC Lua replacement, then disable that earlier random decision.
    local gmst = content.gameSettings.records
    gmst.iRCOriginalBlockMinChance = gmst.iBlockMinChance
    gmst.iRCOriginalBlockMaxChance = gmst.iBlockMaxChance
    gmst.iBlockMinChance = 0
    gmst.iBlockMaxChance = 0
end
