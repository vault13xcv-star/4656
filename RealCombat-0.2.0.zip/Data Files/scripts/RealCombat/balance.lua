-- Engine-independent formulas. Optional settings arguments default to config.lua.
local defaults = require('scripts.RealCombat.config')
local M = {}

local function fail(path, expected)
    error('RealCombat: ' .. path .. ' must be ' .. expected, 3)
end

local function finite(value, path)
    if type(value) ~= 'number' or value ~= value
        or value == math.huge or value == -math.huge then
        fail(path, 'a finite number')
    end
    return value
end

local function number(value, path, minimum, maximum, exclusiveMinimum)
    finite(value, path)
    if minimum and (value < minimum or (exclusiveMinimum and value == minimum)) then
        fail(path, (exclusiveMinimum and 'greater than ' or 'at least ') .. minimum)
    end
    if maximum and value > maximum then
        fail(path, 'at most ' .. maximum)
    end
end

local function section(settings, key)
    if type(settings[key]) ~= 'table' then fail(key, 'a table') end
    return settings[key]
end

local function boolean(value, path)
    if type(value) ~= 'boolean' then fail(path, 'a boolean') end
end

-- Reject missing/wrong-type/non-finite values early with a named setting.
-- Descending endpoint values (wear, fatigue, raising time) are intentional.
function M.validate(settings)
    if type(settings) ~= 'table' then fail('config', 'a table') end
    boolean(settings.enabled, 'enabled')
    local skill = section(settings, 'skill')
    number(skill.min, 'skill.min', 0)
    number(skill.max, 'skill.max', skill.min, nil, true)

    local weapon = section(settings, 'weapon')
    for _, name in ipairs({ 'damage', 'wear', 'fatigue' }) do
        number(weapon[name .. 'Min'], 'weapon.' .. name .. 'Min', 0)
        number(weapon[name .. 'Max'], 'weapon.' .. name .. 'Max', 0)
    end
    for _, suffix in ipairs({ 'Min', 'Max' }) do
        number(weapon['speed' .. suffix], 'weapon.speed' .. suffix, 0, nil, true)
        number(weapon['penetration' .. suffix], 'weapon.penetration' .. suffix, 0, 1)
    end

    local exhaustion = section(settings, 'exhaustion')
    number(exhaustion.damage, 'exhaustion.damage', 0, 1)
    number(exhaustion.speed, 'exhaustion.speed', 0, 1, true)
    number(exhaustion.raiseSpeed, 'exhaustion.raiseSpeed', 0, 1, true)
    number(exhaustion.shieldLeak, 'exhaustion.shieldLeak', 0, 1)

    local shield = section(settings, 'shield')
    boolean(shield.enabled, 'shield.enabled')
    number(shield.button, 'shield.button', 1, 255)
    if shield.button % 1 ~= 0 then fail('shield.button', 'an integer') end
    for _, suffix in ipairs({ 'Min', 'Max' }) do
        number(shield['raiseSeconds' .. suffix], 'shield.raiseSeconds' .. suffix, 0, nil, true)
        number(shield['wear' .. suffix], 'shield.wear' .. suffix, 0)
        number(shield['fatigue' .. suffix], 'shield.fatigue' .. suffix, 0)
    end
    number(shield.wearBase, 'shield.wearBase', 0)
    number(shield.fatigueBase, 'shield.fatigueBase', 0)
    number(shield.heldLeak, 'shield.heldLeak', 0, 1)
    number(shield.perfectSeconds, 'shield.perfectSeconds', 0)
    number(shield.facingDegrees, 'shield.facingDegrees', 0, 360, true)
    number(shield.poseFraction, 'shield.poseFraction', 0, 1)

    local parry = section(settings, 'parry')
    boolean(parry.enabled, 'parry.enabled')
    number(parry.effectiveness, 'parry.effectiveness', 0, 1)
    number(parry.wearMultiplier, 'parry.wearMultiplier', 0)
    number(parry.poseFraction, 'parry.poseFraction', 0, 1)

    local crit = section(settings, 'randomCrit')
    boolean(crit.enabled, 'randomCrit.enabled')
    number(crit.chanceMin, 'randomCrit.chanceMin', 0, 1)
    number(crit.chanceMax, 'randomCrit.chanceMax', 0, 1)
    number(crit.multiplier, 'randomCrit.multiplier', 0)
    if crit.multiplier > 0 and crit.multiplier < 1 then
        fail('randomCrit.multiplier', 'zero (native) or at least one')
    end

    local accuracy = section(settings, 'accuracy')
    boolean(accuracy.enabled, 'accuracy.enabled')
    boolean(accuracy.allMeleeActors, 'accuracy.allMeleeActors')
    -- The engine binding takes an integer; stay inside signed 32-bit range.
    number(accuracy.bonus, 'accuracy.bonus', 0, 2147483647)
    if accuracy.bonus % 1 ~= 0 then fail('accuracy.bonus', 'an integer') end
    boolean(section(settings, 'scope').playerOnlySkillScaling, 'scope.playerOnlySkillScaling')
    boolean(section(settings, 'npcBlock').enabled, 'npcBlock.enabled')
    return settings
end

-- Clamp drained/fortified skills to the configured progression endpoints.
function M.normalizedSkill(skill, settings)
    settings = settings or defaults
    finite(skill, 'skill value')
    local range = settings.skill
    return math.max(0, math.min(1, (skill - range.min) / (range.max - range.min)))
end

-- Unclamped interpolation, useful when both endpoints deliberately descend.
function M.lerp(minimum, maximum, fraction)
    return minimum + (maximum - minimum) * fraction
end

local function interpolate(sectionValue, name, fraction)
    return M.lerp(sectionValue[name .. 'Min'], sectionValue[name .. 'Max'], fraction)
end

-- Returns {damage,speed,penetration,wear,fatigue,critChance}; damage/speed
-- include exhaustion, while progression does not change when fatigue is zero.
function M.weaponModifiers(skill, exhausted, settings)
    settings = settings or defaults
    local t = M.normalizedSkill(skill, settings)
    local w = settings.weapon
    local result = {
        damage = interpolate(w, 'damage', t),
        speed = interpolate(w, 'speed', t),
        penetration = interpolate(w, 'penetration', t),
        wear = interpolate(w, 'wear', t),
        fatigue = interpolate(w, 'fatigue', t),
        critChance = settings.randomCrit.enabled
            and interpolate(settings.randomCrit, 'chance', t) or 0,
    }
    if exhausted then
        result.damage = result.damage * settings.exhaustion.damage
        result.speed = result.speed * settings.exhaustion.speed
    end
    return result
end

-- Returns {raiseSeconds,raiseSpeed,wear,fatigue}. raiseSpeed is the exhaustion
-- speed factor; raiseSeconds already includes it. Do not apply it twice.
-- wearBase/fatigueBase are separate scales for runtime cost calculations.
function M.shieldModifiers(skill, exhausted, settings)
    settings = settings or defaults
    local t = M.normalizedSkill(skill, settings)
    local speed = exhausted and settings.exhaustion.raiseSpeed or 1
    return {
        raiseSeconds = interpolate(settings.shield, 'raiseSeconds', t) / speed,
        raiseSpeed = speed,
        wear = interpolate(settings.shield, 'wear', t),
        fatigue = interpolate(settings.shield, 'fatigue', t),
    }
end

local function guardMultiplier(state, enabled, settings)
    if not settings.enabled or not enabled
        or not state.held or not state.ready or not state.facing then
        return 1, 'unblocked'
    end
    if state.exhausted then return settings.exhaustion.shieldLeak, 'exhausted' end
    local elapsed = finite(state.elapsed, 'guard elapsed')
    if elapsed >= 0 and elapsed <= settings.shield.perfectSeconds then
        return 0, 'perfect'
    end
    return settings.shield.heldLeak, 'held'
end

-- state: {held,ready,facing,exhausted,elapsed}. elapsed is simulation seconds
-- since the guard FINISHED rising. Exhaustion overrides the perfect window.
-- Returns damage multiplier and reason: unblocked/exhausted/perfect/held.
function M.blockMultiplier(state, settings)
    settings = settings or defaults
    return guardMultiplier(state, settings.shield.enabled, settings)
end

-- Parrying prevents a configured fraction of the damage a shield would prevent.
-- Timing, facing and exhaustion are shared, but enabling parries is independent.
function M.parryMultiplier(state, settings)
    settings = settings or defaults
    local multiplier, reason = guardMultiplier(state, settings.parry.enabled, settings)
    return 1 - (1 - multiplier) * settings.parry.effectiveness, reason
end

-- Native durability often consumes whole points. Carry sub-point loss between
-- hits so 0.5x wear becomes 0,1,0,1 instead of rounding every hit up to one.
-- Returns whole loss and carry in [0,1). Keep carry per weapon and save it.
function M.wearCost(baseCost, multiplier, carry)
    carry = carry or 0
    number(baseCost, 'wear baseCost', 0)
    number(multiplier, 'wear multiplier', 0)
    number(carry, 'wear carry', 0, 1)
    if carry == 1 then fail('wear carry', 'less than one') end
    local cost = finite(baseCost * multiplier + carry, 'wear total')
    local whole = math.floor(cost + 1e-12)
    return whole, math.max(0, cost - whole)
end

-- Reconcile an already-applied native integer loss with the intended cost.
-- Positive conditionDelta repairs only that hit's excess wear; negative adds
-- missing wear. Runtime must separately handle native premature unequipping.
function M.wearAdjustment(vanillaLoss, multiplier, carry)
    local wanted, remainder = M.wearCost(vanillaLoss, multiplier, carry)
    return vanillaLoss - wanted, remainder
end

M.validate(defaults)
return M
