local core = require('openmw.core')
local types = require('openmw.types')
local self = require('openmw.self')
local I = require('openmw.interfaces')
local animation = require('openmw.animation')
local config = require('scripts.RealCombat.config')
local balance = require('scripts.RealCombat.balance')
local engine = require('scripts.RealCombat.engine')
local attackState = require('scripts.RealCombat.attack_state')
local npcBlock = require('scripts.RealCombat.npc_block')
local Actor = types.Actor
local isPlayer = types.Player.objectIsInstance(self)
assert(I.Combat and I.Combat.version >= 1 and I.AnimationController,
    'Real Combat requires OpenMW 0.51.0 or newer with the Combat interface.')
balance.validate(config)
local shield = isPlayer and require('scripts.RealCombat.shield').new(config, balance) or nil
local swings, latestSwing, currentAnimation = {}, nil, nil
local warnedAnimation, warnedMiss = false, false
local accuracyId = 'rc_melee_accuracy'
local godMode = isPlayer and require('openmw.debug').isGodMode or function() return false end

local function modifiers(actor, weapon)
    return balance.weaponModifiers(engine.skill(actor, engine.weaponSkill(weapon)),
        Actor.stats.dynamic.fatigue(actor).current <= 0, config)
end

local function updateAccuracy()
    local weapon = engine.weapon(self)
    -- An empty right hand is unarmed melee. Lockpicks/probes are not melee.
    local carried = Actor.getEquipment(self, Actor.EQUIPMENT_SLOT.CarriedRight)
    local melee = (not carried or engine.meleeWeapon(weapon))
        and Actor.getStance(self) == Actor.STANCE.Weapon
    local wanted = config.enabled and config.accuracy.enabled and not Actor.isDead(self)
        and (isPlayer or config.accuracy.allMeleeActors) and melee
    local spells = Actor.spells(self)
    if wanted and not spells[accuracyId] then spells:add(accuracyId)
    elseif not wanted and spells[accuracyId] then spells:remove(accuracyId) end
end

local function onPlayAnimation(group, options)
    if not config.enabled then return end
    if currentAnimation and currentAnimation.group == group
        and not attackState.isAttackPhase(options.startKey) and not attackState.isAttackPhase(options.stopKey) then
        currentAnimation = nil
    end
    local weapon = engine.weapon(self)
    if not engine.meleeWeapon(weapon) or not engine.scaledActor(self, config) then return end
    if not attackState.isAttackPhase(options.startKey) and not attackState.isAttackPhase(options.stopKey) then return end
    local values = modifiers(self, weapon)
    currentAnimation = {group = group, baseSpeed = options.speed or 1, item = weapon}
    options.speed = (options.speed or 1) * values.speed
    local kind = options.stopKey and options.stopKey:match('^(%a+) hit$')
    if not kind or not (options.startKey or ''):match(' max attack$') then return end
    local strength = attackState.releaseStrength(options.startPoint,
        animation.getTextKeyTime(self, group .. ': ' .. kind .. ' max attack'),
        animation.getTextKeyTime(self, group .. ': ' .. kind .. ' min hit'),
        animation.getTextKeyTime(self, group .. ': ' .. kind .. ' hit'))
    -- Standard Morrowind animation tracks expose the three timing keys.
    -- Do not guess a charge on unsupported replacement animations.
    if not strength then
        if not warnedAnimation then
            print('[Real Combat] Cannot infer attack charge from this animation; empty-air fatigue discount unavailable.')
            warnedAnimation = true
        end
    end
    latestSwing = {
        item = weapon, before = types.Item.itemData(weapon).condition,
        kind = kind, strength = strength, group = group,
        values = values, time = core.getSimulationTime(), fatigueDone = false,
    }
    swings[#swings + 1] = latestSwing
    -- Only unresolved, recent attacks are needed; avoid keeping item references
    -- forever after a miss or switching cells.
    while #swings > 12 do table.remove(swings, 1) end
end

local function refundFatigue(swing, strength)
    if swing.fatigueDone or godMode() or not strength then return end
    swing.fatigueDone = true
    local refund = engine.attackFatigue(self, swing.item, strength) * (1 - swing.values.fatigue)
    local fatigue = Actor.stats.dynamic.fatigue(self)
    fatigue.current = fatigue.current + refund
end

local function onTextKey(group, key)
    if not config.enabled then return end
    local kind = key:match('^(%a+) hit$')
    if not kind then return end
    local swing = latestSwing
    if swing and swing.group == group and swing.kind == kind and not swing.hitKey then
        swing.hitKey = true
        refundFatigue(swing, swing.strength)
    end
end

local function onContact(data)
    if not config.enabled or godMode() or not data.weapon or not engine.scaledActor(self, config) then return end
    local now = core.getSimulationTime()
    local kind = ({[0] = 'chop', [1] = 'slash', [2] = 'thrust'})[data.type]
    for index = #swings, 1, -1 do
        local swing = swings[index]
        if not swing.contact and swing.hitKey and swing.item == data.weapon and swing.kind == kind
            and (not swing.strength or math.abs(swing.strength - data.strength) < 1e-4)
            and now - swing.time < 10 then
            swing.contact = true
            refundFatigue(swing, data.strength)
            local raw = data.successful and engine.rawWeaponDamage(self, data.weapon,
                data.strength, data.type, swing.before) or 0
            local nativeWear = math.floor(math.max(1, core.getGMST('fWeaponDamageMult') * raw))
            core.sendGlobalEvent('RC_CorrectWeaponWear', {
                actor = self, item = data.weapon, before = swing.before,
                nativeWear = nativeWear, multiplier = swing.values.wear,
            })
            break
        end
    end
end

local function onHit(attack)
    if not config.enabled or attack.sourceType ~= I.Combat.ATTACK_SOURCE_TYPES.Melee then return end
    local attacker, weapon = attack.attacker, attack.weapon
    if attacker and weapon and engine.meleeWeapon(weapon) then
        attacker:sendEvent('RC_Contact', {
            weapon = weapon, strength = attack.strength, type = attack.type, successful = attack.successful,
        })
    end
    if not attack.successful then
        -- Converting a failed native roll here would miss enchantments, crits,
        -- skill XP and resistances. Never fabricate a partial replacement hit.
        if config.accuracy.enabled and not warnedMiss then
            print('[Real Combat] Native melee miss observed: check accuracy ability, load order or extreme modded stats.')
            warnedMiss = true
        end
        return
    end
    if not attack.damage then return end
    if attacker and engine.meleeWeapon(weapon) and engine.scaledActor(attacker, config) then
        local skill = engine.skill(attacker, engine.weaponSkill(weapon))
        local values = balance.weaponModifiers(skill, false, config)
        -- Native Hit events run before animation text-key handlers. Account for
        -- THIS swing's pending discount before deciding whether it exhausted
        -- the attacker; otherwise high-skill attacks are penalized too early.
        local effectiveFatigue = Actor.stats.dynamic.fatigue(attacker).current
            + engine.attackFatigue(attacker, weapon, attack.strength) * (1 - values.fatigue)
        if effectiveFatigue <= 0 then values.damage = values.damage * config.exhaustion.damage end
        for statName, damage in pairs(attack.damage) do attack.damage[statName] = damage * values.damage end
        attack.rcPenetrates = math.random() < values.penetration
        if config.randomCrit.enabled and math.random() < values.critChance then
            local factor = config.randomCrit.multiplier == 0
                and core.getGMST('fCombatCriticalStrikeMult') or config.randomCrit.multiplier
            for statName, damage in pairs(attack.damage) do attack.damage[statName] = damage * factor end
        end
    end
    if shield and not godMode() then
        local healthBeforeBlock = attack.damage.health
        local result = shield.apply(attack)
        if result and result.blocked then
            attack.rcBlocked = true
            attack.rcDefenseMode = result.mode or 'shield'
            attack.rcShieldMultiplier = result.multiplier
            -- Let armor calculate mitigation for the original hit, then apply
            -- the defense fraction. Armor is nonlinear and has a minimum of 1.
            attack.damage.health = healthBeforeBlock
        end
    elseif not isPlayer then
        local attacking = latestSwing and core.getSimulationTime() - latestSwing.time < 0.5
        npcBlock.apply(attack, config, attacking)
    end
end

I.Combat.addOnHitHandler(onHit)
I.AnimationController.addPlayBlendedAnimationHandler(onPlayAnimation)
I.AnimationController.addTextKeyHandler('', onTextKey)

-- A public interface override is the supported way to interpose on armor.
-- Keep every unrelated method, including other mods' earlier overrides.
local previous = I.Combat
local interface = {}
for key, value in pairs(previous) do interface[key] = value end
interface.applyArmor = function(attack)
    if not config.enabled or attack.sourceType ~= previous.ATTACK_SOURCE_TYPES.Melee then
        return previous.applyArmor(attack)
    end
    if attack.rcShieldMultiplier == 0 then
        attack.damage.health = 0
        return
    end
    if not attack.rcPenetrates and not (attack.rcBlocked and (attack.damage.health or 0) <= 0) then
        previous.applyArmor(attack)
    end
    if attack.rcShieldMultiplier and attack.damage.health then
        attack.damage.health = attack.damage.health * attack.rcShieldMultiplier
    end
end
interface.realCombatCanDefend = function() return shield and shield.canRaise() or false end
-- Preserve the prototype interface name for clients already using it.
interface.realCombatCanRaiseShield = interface.realCombatCanDefend

return {
    interfaceName = 'Combat', interface = interface,
    engineHandlers = {
        onUpdate = function(dt)
            updateAccuracy()
            if shield then shield.update(dt) end
            if config.enabled and currentAnimation and animation.isPlaying(self, currentAnimation.group)
                and not (shield and shield.ownsPose(currentAnimation.group))
                and engine.weapon(self) == currentAnimation.item then
                animation.setSpeed(self, currentAnimation.group,
                    currentAnimation.baseSpeed * modifiers(self, currentAnimation.item).speed)
            end
            local now = core.getSimulationTime()
            for index = #swings, 1, -1 do
                if now - swings[index].time > 10 then table.remove(swings, index) end
            end
        end,
        onFrame = isPlayer and function()
            if shield then shield.suppressAttack() end
        end or nil,
        onLoad = function()
            swings, latestSwing, currentAnimation = {}, nil, nil
            if shield then shield.load() end
        end,
    },
    eventHandlers = {
        RC_Contact = onContact,
        RC_ParryWearApplied = function(data)
            if shield then shield.acknowledgeWear(data) end
        end,
        RC_RestoreWeapon = function(data)
            if not config.enabled or not data.item or not data.item:isValid() then return end
            if Actor.getEquipment(self, Actor.EQUIPMENT_SLOT.CarriedRight)
                or types.Item.itemData(data.item).condition <= 0 then return end
            local equipment = Actor.getEquipment(self)
            equipment[Actor.EQUIPMENT_SLOT.CarriedRight] = data.item
            Actor.setEquipment(self, equipment)
        end,
    },
}
