-- Small shared adapter; no game state is changed merely by requiring it.
local core = require('openmw.core')
local types = require('openmw.types')
local Actor, Weapon = types.Actor, types.Weapon
local M = {}
local skillByType = {
    [Weapon.TYPE.ShortBladeOneHand] = 'shortblade',
    [Weapon.TYPE.LongBladeOneHand] = 'longblade',
    [Weapon.TYPE.LongBladeTwoHand] = 'longblade',
    [Weapon.TYPE.BluntOneHand] = 'bluntweapon',
    [Weapon.TYPE.BluntTwoClose] = 'bluntweapon',
    [Weapon.TYPE.BluntTwoWide] = 'bluntweapon',
    [Weapon.TYPE.SpearTwoWide] = 'spear',
    [Weapon.TYPE.AxeOneHand] = 'axe',
    [Weapon.TYPE.AxeTwoHand] = 'axe',
}

function M.weapon(actor)
    local item = Actor.getEquipment(actor, Actor.EQUIPMENT_SLOT.CarriedRight)
    if item and Weapon.objectIsInstance(item) then return item end
end

function M.meleeWeapon(item)
    return item and Weapon.objectIsInstance(item)
        and skillByType[Weapon.record(item).type] ~= nil
end

function M.weaponSkill(item)
    return item and skillByType[Weapon.record(item).type] or 'handtohand'
end

function M.skill(actor, id)
    if types.Creature.objectIsInstance(actor) then
        local specialization = core.stats.Skill.record(id).specialization
        return types.Creature.record(actor)[specialization .. 'Skill']
    end
    return types.NPC.stats.skills[id](actor).modified
end

function M.scaledActor(actor, config)
    return not config.scope.playerOnlySkillScaling or types.Player.objectIsInstance(actor)
end

function M.fatigueTerm(actor)
    local fatigue = Actor.stats.dynamic.fatigue(actor)
    local maximum = fatigue.base + fatigue.modifier
    local fraction = math.floor(maximum) == 0 and 1
        or math.max(0, fatigue.current / maximum)
    return core.getGMST('fFatigueBase') - core.getGMST('fFatigueMult') * (1 - fraction)
end

function M.encumbrance(actor)
    local capacity = Actor.getCapacity(actor)
    local weight = Actor.getEncumbrance(actor)
    if capacity > 0 then return weight / capacity end
    return weight > 0 and (1 + 1e-6) or 0
end

function M.attackFatigue(actor, item, strength)
    return core.getGMST('fFatigueAttackBase')
        + M.encumbrance(actor) * core.getGMST('fFatigueAttackMult')
        + (item and Weapon.record(item).weight or 0) * strength * core.getGMST('fWeaponFatigueMult')
end

function M.rawWeaponDamage(actor, item, strength, attackType, condition)
    local record = Weapon.record(item)
    local prefix = ({[0] = 'chop', [1] = 'slash', [2] = 'thrust'})[attackType] or 'chop'
    local low, high = record[prefix .. 'MinDamage'], record[prefix .. 'MaxDamage']
    local strengthFactor = core.getGMST('fDamageStrengthBase')
        + Actor.stats.attributes.strength(actor).modified * core.getGMST('fDamageStrengthMult') * 0.1
    return (low + (high - low) * strength)
        * (record.health > 0 and math.floor(condition) / record.health or 0) * strengthFactor
end

function M.inFront(defender, attacker, degrees)
    if not attacker or not attacker:isValid() then return false end
    local delta = attacker.position - defender.position
    local forward = defender.rotation:apply(require('openmw.util').vector3(0, 1, 0))
    local distance = math.sqrt(delta.x * delta.x + delta.y * delta.y)
    local length = math.sqrt(forward.x * forward.x + forward.y * forward.y)
    if distance < 0.001 or length < 0.001 then return true end
    return (delta.x * forward.x + delta.y * forward.y) / (distance * length)
        >= math.cos(math.rad(degrees / 2))
end

return M
