local I = require('openmw.interfaces')
local input = require('openmw.input')
local config = require('scripts.RealCombat.config')
local previous = I.UI
local interface = {}
for key, value in pairs(previous) do interface[key] = value end

-- The default RMB binding opens Inventory before onFrame. Intercept just that
-- UI transition while a shield or melee parry is usable; other controls work.
interface.setMode = function(mode, ...)
    if config.enabled and mode == previous.MODE.Interface and previous.getMode() == nil
        and input.isMouseButtonPressed(config.shield.button)
        and I.Combat.realCombatCanDefend() then return end
    return previous.setMode(mode, ...)
end

return { interfaceName = 'UI', interface = interface }
