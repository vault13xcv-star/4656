-- Engine-independent swing bookkeeping. One text-key notification spends
-- fatigue once; wind-up/release/follow-through never count as additional hits.
local M = {}
function M.isAttackPhase(key)
    return type(key) == 'string' and
        (key:match('^chop ') or key:match('^slash ') or key:match('^thrust ')) ~= nil
end
function M.releaseStrength(startPoint, maxAttack, minHit, hit)
    if not maxAttack or not hit or maxAttack < 0 or hit <= maxAttack then return nil end
    local fraction = 1
    if maxAttack and minHit and hit and maxAttack <= minHit and minHit < hit then
        fraction = (minHit - maxAttack) / (hit - maxAttack)
    end
    if fraction <= 0 then return nil end
    return math.max(0, math.min(1, 1 - (startPoint or 0) / fraction))
end
function M.correctWear(before, after, nativeWear, multiplier, remainder)
    local exact = nativeWear * multiplier + (remainder or 0)
    local desired = math.floor(exact + 1e-9)
    local nativeApplied = math.min(math.floor(before), nativeWear)
    -- Apply a delta, preserving unrelated condition loss/repairs.
    return math.max(0, after + nativeApplied - desired), math.max(0, exact - desired)
end
return M
