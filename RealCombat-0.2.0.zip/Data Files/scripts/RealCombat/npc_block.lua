-- Native random block is disabled before Hit. Keep NPC shields useful with a
-- Lua version of the vanilla probability, fatigue cost and durability loss.
local core = require('openmw.core')
local types = require('openmw.types')
local anim = require('openmw.animation')
local self = require('openmw.self')
local engine = require('scripts.RealCombat.engine')
local Actor = types.Actor
local M = {}

function M.apply(attack, config, attacking)
    if not config.shield.enabled or not config.npcBlock.enabled or attacking
        or not types.NPC.objectIsInstance(self) or Actor.isDead(self) or not Actor.canMove(self)
        or Actor.getStance(self) ~= Actor.STANCE.Weapon
        or Actor.activeEffects(self):getEffect(core.magic.EFFECT_TYPE.Paralyze).magnitude > 0
        or not engine.inFront(self, attack.attacker, config.shield.facingDegrees) then return end
    local shield = Actor.getEquipment(self, Actor.EQUIPMENT_SLOT.CarriedLeft)
    if not shield or not types.Armor.objectIsInstance(shield)
        or types.Armor.record(shield).type ~= types.Armor.TYPE.Shield
        or types.Item.itemData(shield).condition <= 0 then return end
    local weapon = engine.weapon(self)
    local oneHand = weapon and ({
        [types.Weapon.TYPE.ShortBladeOneHand] = true,
        [types.Weapon.TYPE.LongBladeOneHand] = true,
        [types.Weapon.TYPE.BluntOneHand] = true,
        [types.Weapon.TYPE.AxeOneHand] = true,
    })[types.Weapon.record(weapon).type]
    if not oneHand then return end
    local function stat(actor, id) return Actor.stats.attributes[id](actor).modified end
    local blockTerm = engine.skill(self, 'block') + 0.2 * stat(self, 'agility') + 0.1 * stat(self, 'luck')
    blockTerm = blockTerm * (attack.strength * core.getGMST('fSwingBlockMult') + core.getGMST('fSwingBlockBase'))
    if self.controls.movement <= 0 then blockTerm = blockTerm * core.getGMST('fBlockStillBonus') end
    blockTerm = blockTerm * engine.fatigueTerm(self)
    local attacker = attack.attacker
    local attackTerm = engine.skill(attacker, engine.weaponSkill(attack.weapon))
        + 0.2 * stat(attacker, 'agility') + 0.1 * stat(attacker, 'luck')
    attackTerm = attackTerm * engine.fatigueTerm(attacker)
    local chance = math.max(core.getGMST('iRCOriginalBlockMinChance'),
        math.min(core.getGMST('iRCOriginalBlockMaxChance'), math.floor(blockTerm - attackTerm)))
    if math.random() * 100 >= chance then return end
    local damage = (attack.damage.health or 0) + (attack.damage.fatigue or 0)
    core.sendGlobalEvent('ModifyItemCondition', {actor = self, item = shield, amount = -math.floor(damage)})
    local cost = core.getGMST('fFatigueBlockBase')
        + math.min(1, engine.encumbrance(self)) * core.getGMST('fFatigueBlockMult')
        + (attack.weapon and types.Weapon.record(attack.weapon).weight or 0)
            * attack.strength * core.getGMST('fWeaponFatigueBlockMult')
    local fatigue = Actor.stats.dynamic.fatigue(self)
    fatigue.current = fatigue.current - cost
    for statName in pairs(attack.damage) do attack.damage[statName] = 0 end
    attack.rcBlocked = true
    if anim.hasGroup(self, 'shield') then
        require('openmw.interfaces').AnimationController.playBlendedAnimation('shield', {
            startKey = 'block start', stopKey = 'block stop',
            priority = anim.PRIORITY.Block, blendMask = anim.BLEND_MASK.LeftArm,
        })
    end
    core.sound.playSound3d('Light Armor Hit', self)
end
return M
