-- OpenMW 0.51 adapter for active shield blocking and weapon parrying.
-- Native random blocking is disabled by the companion LOAD script.
local State = require('scripts.RealCombat.shield_state')
local M = {}

function M.new(config, balance)
    local core = require('openmw.core')
    local input = require('openmw.input')
    local self = require('openmw.self')
    local types = require('openmw.types')
    local util = require('openmw.util')
    local animation = require('openmw.animation')
    local I = require('openmw.interfaces')
    local engine = require('scripts.RealCombat.engine')
    local Actor, Armor, Weapon = types.Actor, types.Armor, types.Weapon
    local state = State.new()
    local poseActive, posePoint, poseGroup = false, nil, nil
    local warnedAnimation = {}
    local trackedShield, observedCondition, pendingWear = nil, 0, 0
    local parryRequests, nextRequest = {}, 0
    local heldMode, heldItem, heldWeapon = nil, nil, nil
    local attackAnimation = nil

    local oneHanded = {
        [Weapon.TYPE.ShortBladeOneHand] = true,
        [Weapon.TYPE.LongBladeOneHand] = true,
        [Weapon.TYPE.BluntOneHand] = true,
        [Weapon.TYPE.AxeOneHand] = true,
    }
    -- Mirrors CharacterController::getWeaponAnimation, including fallbacks.
    local weaponGroups = {
        [Weapon.TYPE.ShortBladeOneHand] = 'shortbladeonehand',
        [Weapon.TYPE.LongBladeOneHand] = 'weapononehand',
        [Weapon.TYPE.BluntOneHand] = 'bluntonehand',
        [Weapon.TYPE.AxeOneHand] = 'bluntonehand',
        [Weapon.TYPE.LongBladeTwoHand] = 'weapontwohand',
        [Weapon.TYPE.AxeTwoHand] = 'blunttwohand',
        [Weapon.TYPE.BluntTwoClose] = 'blunttwohand',
        [Weapon.TYPE.BluntTwoWide] = 'weapontwowide',
        [Weapon.TYPE.SpearTwoWide] = 'weapontwowide',
    }

    -- Releasing Use starts an attack; wait for its follow-through before raising.
    -- Equipment transitions must also finish before replacing the weapon track.
    I.AnimationController.addPlayBlendedAnimationHandler(function(group, options)
        if poseActive and poseGroup == group then
            -- A native transition takes ownership after this handler returns.
            -- Remove the frozen track first: replaying an existing group can
            -- otherwise retain its old start position and zero playback speed.
            if animation.hasAnimation(self) then animation.cancel(self, group) end
            poseActive, posePoint, poseGroup = false, nil, nil
        end
        local key = options.startKey or ''
        if key:match('^chop ') or key:match('^slash ') or key:match('^thrust ')
            or key:match('^equip ') or key:match('^unequip ') then
            attackAnimation = { group = group, stopKey = options.stopKey or '' }
        elseif attackAnimation and attackAnimation.group == group then
            attackAnimation = nil
        end
    end)

    local function attacking()
        if not attackAnimation then return false end
        if not animation.hasAnimation(self) then return true end
        local completion = animation.getCompletion(self, attackAnimation.group)
        local finishes = attackAnimation.stopKey:match(' follow stop$')
            or attackAnimation.stopKey == 'equip stop' or attackAnimation.stopKey == 'unequip stop'
        if completion == nil or (finishes and completion >= 1) then
            attackAnimation = nil
            return false
        end
        return true
    end

    -- Shield writes use the standard global event. Account for queued writes so
    -- several hits in one update cannot block with a shield already broken.
    local function shieldCondition(shield)
        local condition = types.Item.itemData(shield).condition
        if trackedShield ~= shield then
            trackedShield, observedCondition, pendingWear = shield, condition, 0
        else
            pendingWear = math.max(0, pendingWear - math.max(0, observedCondition - condition))
            observedCondition = condition
        end
        return math.max(0, condition - pendingWear)
    end

    local function weaponCondition(weapon)
        local reserved = 0
        for _, request in pairs(parryRequests) do
            if request.item == weapon then reserved = reserved + request.wear end
        end
        return math.max(0, types.Item.itemData(weapon).condition - reserved)
    end

    local function acknowledgeWear(data)
        local pending = parryRequests[data.requestId]
        if pending and pending.item == data.item then parryRequests[data.requestId] = nil end
    end

    local function equippedDefense()
        local weapon = Actor.getEquipment(self, Actor.EQUIPMENT_SLOT.CarriedRight)
        if not engine.meleeWeapon(weapon) then return nil end
        local shield = Actor.getEquipment(self, Actor.EQUIPMENT_SLOT.CarriedLeft)
        if shield and Armor.objectIsInstance(shield) and Armor.record(shield).type == Armor.TYPE.Shield then
            -- Even a broken/disabled shield excludes weapon parrying until removed.
            if config.shield.enabled and oneHanded[Weapon.record(weapon).type]
                and shieldCondition(shield) > 0 then
                return 'shield', shield, weapon
            end
            return nil
        end
        if config.parry.enabled and weaponCondition(weapon) > 0 then
            return 'parry', weapon, weapon
        end
    end

    local function incapacitated()
        -- Public canMove also sees native knockdown before its animation begins.
        if not Actor.canMove(self) or Actor.isDead(self) or Actor.isSwimming(self) then return true end
        if Actor.activeEffects(self):getEffect(core.magic.EFFECT_TYPE.Paralyze).magnitude > 0 then
            return true
        end
        if animation.hasAnimation(self) then
            local group = animation.getActiveGroup(self, animation.BONE_GROUP.LowerBody) or ''
            if group:find('knockdown', 1, true) or group:find('knockout', 1, true)
                or group:match('^hit%d*$') or group:match('^swimhit%d*$') then
                return true
            end
        end
        return false
    end

    local function canRaise()
        if not config.enabled or I.UI.getMode() ~= nil or core.isWorldPaused()
            or Actor.getStance(self) ~= Actor.STANCE.Weapon or incapacitated() then
            return false
        end
        if not types.Player.getControlSwitch(self, types.Player.CONTROL_SWITCH.Controls)
            or not types.Player.getControlSwitch(self, types.Player.CONTROL_SWITCH.Fighting) then
            return false
        end
        return equippedDefense() ~= nil
    end

    local function stopPose()
        if poseActive and animation.hasAnimation(self) then animation.cancel(self, poseGroup) end
        poseActive, posePoint, poseGroup = false, nil, nil
    end

    local function showPose(mode, weapon, progress)
        local group, startKey, stopKey, fraction, mask
        if mode == 'shield' then
            group, startKey, stopKey = 'shield', 'block start', 'block stop'
            fraction, mask = config.shield.poseFraction, animation.BLEND_MASK.LeftArm
        else
            local weaponType = Weapon.record(weapon).type
            group = weaponGroups[weaponType]
            if animation.hasAnimation(self) and not animation.hasGroup(self, group) then
                group = oneHanded[weaponType] and 'weapononehand' or 'weapontwohand'
            end
            startKey, stopKey = 'chop min attack', 'chop max attack'
            fraction, mask = config.parry.poseFraction, animation.BLEND_MASK.UpperBody
        end
        local hasGroup = animation.hasAnimation(self) and animation.hasGroup(self, group)
        local startTime = hasGroup and animation.getTextKeyTime(self, group .. ': ' .. startKey)
        local stopTime = hasGroup and animation.getTextKeyTime(self, group .. ': ' .. stopKey)
        local valid = startTime and stopTime and startTime < stopTime
        if mode == 'parry' and valid then
            -- Never enter any attack hit section, even with replacement tracks.
            local hitTime = animation.getTextKeyTime(self, group .. ': chop hit')
            valid = hitTime and stopTime < hitTime
        end
        if not valid then
            stopPose()
            if not warnedAnimation[mode] then
                print('[RealCombat] ' .. mode .. ' pose unavailable; timed defense remains active.')
                warnedAnimation[mode] = true
            end
            return
        end
        local point = math.min(0.99, math.max(0, fraction * progress))
        if poseActive and poseGroup == group and posePoint == point
            and animation.isPlaying(self, group) then return end
        if poseActive and poseGroup ~= group then stopPose() end
        -- Replaying an active group only changes priority; cancel to scrub it.
        animation.cancel(self, group)
        local options = {
            startKey = startKey, stopKey = stopKey, blendMask = mask,
            priority = animation.PRIORITY.Block, autoDisable = false,
            speed = 0, startPoint = point,
        }
        if mode == 'shield' then
            I.AnimationController.playBlendedAnimation(group, options)
        else
            -- A frozen pre-hit pose must not notify attack animation hooks or
            -- create attack-fatigue refunds and weapon-hit bookkeeping.
            animation.playBlended(self, group, options)
        end
        poseActive, posePoint, poseGroup = true, point, group
    end

    local function reset()
        state.reset()
        heldMode, heldItem, heldWeapon = nil, nil, nil
        stopPose()
    end

    local function suppressAttack()
        if canRaise() and input.isMouseButtonPressed(config.shield.button) then
            self.controls.use = self.ATTACK_TYPE.NoAttack
        end
    end

    local function defenseSkill(mode, weapon)
        return mode == 'shield' and types.NPC.stats.skills.block(self).modified
            or engine.skill(self, engine.weaponSkill(weapon))
    end

    local function update(dt)
        if not canRaise() or not input.isMouseButtonPressed(config.shield.button) then
            reset()
            return
        end
        suppressAttack()
        if attacking() then reset(); return end
        local mode, item, weapon = equippedDefense()
        if heldMode and (heldMode ~= mode or heldItem ~= item or heldWeapon ~= weapon) then reset() end
        heldMode, heldItem, heldWeapon = mode, item, weapon
        local fatigue = Actor.stats.dynamic.fatigue(self).current
        local modifiers = balance.shieldModifiers(defenseSkill(mode, weapon), fatigue <= 0, config)
        local current = state.update(dt, true, modifiers.raiseSeconds)
        suppressAttack()
        showPose(mode, weapon, current.progress)
    end

    local function facing(attacker)
        if not attacker then return false end
        local delta = attacker.position - self.position
        local forward = self.rotation:apply(util.vector3(0, 1, 0))
        local distance = math.sqrt(delta.x * delta.x + delta.y * delta.y)
        local forwardLength = math.sqrt(forward.x * forward.x + forward.y * forward.y)
        if distance < 1e-6 or forwardLength < 1e-6 then return false end
        local cosine = (delta.x * forward.x + delta.y * forward.y) / (distance * forwardLength)
        return cosine >= math.cos(math.rad(config.shield.facingDegrees / 2))
    end

    local function staminaCost(attack, multiplier)
        local capacity = Actor.getCapacity(self)
        local encumbrance = capacity > 0 and math.min(1, Actor.getEncumbrance(self) / capacity) or 1
        local cost = core.getGMST('fFatigueBlockBase')
            + math.max(0, encumbrance) * core.getGMST('fFatigueBlockMult')
        if attack.weapon and Weapon.objectIsInstance(attack.weapon) then
            cost = cost + Weapon.record(attack.weapon).weight
                * math.min(1, math.max(0, attack.strength or 0))
                * core.getGMST('fWeaponFatigueBlockMult')
        end
        return math.max(0, cost * multiplier * config.shield.fatigueBase)
    end

    local function apply(attack)
        if not attack.successful or attack.sourceType ~= I.Combat.ATTACK_SOURCE_TYPES.Melee
            or not attack.damage or not canRaise() or attacking()
            or not input.isMouseButtonPressed(config.shield.button) then
            return nil
        end
        local current = state.snapshot()
        if not current.held or not current.ready or not facing(attack.attacker) then return nil end
        local mode, item, weapon = equippedDefense()
        if mode ~= heldMode or item ~= heldItem or weapon ~= heldWeapon then return nil end
        local raw = math.max(0, attack.damage.health or 0) + math.max(0, attack.damage.fatigue or 0)
        if raw <= 0 or (mode == 'parry' and config.parry.effectiveness == 0) then return nil end

        local fatigue = Actor.stats.dynamic.fatigue(self)
        local skill = defenseSkill(mode, weapon)
        local modifiers = balance.shieldModifiers(skill, fatigue.current <= 0, config)
        local cost = staminaCost(attack, modifiers.fatigue)
        -- Do not heal pre-existing negative fatigue. The exhausting hit also
        -- loses perfect-defense protection immediately.
        fatigue.current = math.min(fatigue.current, math.max(0, fatigue.current - cost))
        current.facing, current.exhausted = true, fatigue.current <= 0
        local multiplier, reason
        if mode == 'shield' then multiplier, reason = balance.blockMultiplier(current, config)
        else multiplier, reason = balance.parryMultiplier(current, config) end
        local absorbed = raw * (1 - multiplier)
        attack.damage.health = (attack.damage.health or 0) * multiplier
        if attack.damage.fatigue then attack.damage.fatigue = attack.damage.fatigue * multiplier end
        attack._rcBlocked = true

        local wear = 0
        if mode == 'shield' then
            wear = math.min(shieldCondition(item), math.max(0,
                absorbed * config.shield.wearBase * modifiers.wear))
            if wear > 0 then
                pendingWear = pendingWear + wear
                core.sendGlobalEvent('ModifyItemCondition', { actor = self, item = item, amount = -wear })
            end
        elseif absorbed > 0 then
            -- Compare with a successful attack by this weapon at the incoming
            -- charge/type. Its own condition/strength determine native wear.
            local condition = weaponCondition(weapon)
            local damage = engine.rawWeaponDamage(self, weapon,
                math.min(1, math.max(0, attack.strength or 0)), attack.type, condition)
            local baseWear = math.floor(math.max(1, core.getGMST('fWeaponDamageMult') * damage))
            local multiplierWear = balance.weaponModifiers(skill, false, config).wear * config.parry.wearMultiplier
            wear = math.min(condition, baseWear * multiplierWear)
            if wear > 0 then
                nextRequest = nextRequest + 1
                -- Global fractional carry may round the eventual loss up.
                -- Reserve the upper bound until acknowledgement, keeping the
                -- actual cost fractional in the shared global wear accumulator.
                parryRequests[nextRequest] = { item = item, wear = math.min(condition, math.ceil(wear)) }
                core.sendGlobalEvent('RC_ParryWear', {
                    actor = self, item = item, baseWear = baseWear,
                    multiplier = multiplierWear, requestId = nextRequest,
                })
            end
        end
        if absorbed > 0 then
            if mode == 'shield' then
                I.SkillProgression.skillUsed('block', {
                    useType = I.SkillProgression.SKILL_USE_TYPES.Block_Success,
                })
                local armorSkill = I.Combat.getArmorSkill(item)
                local sound = armorSkill == 'heavyarmor' and 'Heavy Armor Hit'
                    or armorSkill == 'mediumarmor' and 'Medium Armor Hit' or 'Light Armor Hit'
                core.sound.playSound3d(sound, self)
            else
                I.SkillProgression.skillUsed(engine.weaponSkill(weapon), {
                    useType = I.SkillProgression.SKILL_USE_TYPES.Weapon_SuccessfulHit,
                })
                -- Existing vanilla impact sound; no external audio asset needed.
                core.sound.playSound3d('Heavy Armor Hit', self)
            end
        end
        return { blocked = true, mode = mode, perfect = reason == 'perfect', reason = reason,
            multiplier = multiplier, absorbed = absorbed, fatigueCost = cost, wear = wear }
    end

    return {
        update = update, apply = apply, canRaise = canRaise, acknowledgeWear = acknowledgeWear,
        reset = reset, load = function()
            attackAnimation, parryRequests = nil, {}
            trackedShield, observedCondition, pendingWear = nil, 0, 0
            reset()
        end,
        suppressAttack = suppressAttack, state = state.snapshot,
        isParrying = function() return heldMode == 'parry' and state.snapshot().held end,
        ownsPose = function(group) return poseActive and poseGroup == group end,
    }
end

return M
