local types = require('openmw.types')
local config = require('scripts.RealCombat.config')
local state = require('scripts.RealCombat.attack_state')
local remainders = {}

local function correctWeaponWear(data)
    if not config.enabled or not data.item or not data.item:isValid()
        or not data.actor or not data.actor:isValid() then return end
    local item, actor = data.item, data.actor
    if not types.Weapon.objectIsInstance(item) then return end
    -- Ignore dropped/transferred weapons: do not repair somebody else's item.
    local owned = false
    for _, candidate in ipairs(types.Actor.inventory(actor):getAll()) do
        if candidate == item then owned = true; break end
    end
    if not owned then return end
    local itemData = types.Item.itemData(item)
    local current = itemData.condition
    local nextCondition, carry = state.correctWear(
        data.before, current, data.nativeWear, data.multiplier, remainders[item.id] or 0)
    remainders[item.id] = carry
    nextCondition = math.min(types.Weapon.record(item).health, nextCondition)
    itemData.condition = nextCondition
    if nextCondition <= 0 then
        actor:sendEvent('Unequip', {item = item})
    elseif current <= 0 then
        -- C++ may already have unequipped a weapon which this mod would not
        -- have broken. Restore only an empty hand, never replace a new choice.
        actor:sendEvent('RC_RestoreWeapon', {item = item})
    end
end

return {
    eventHandlers = { RC_CorrectWeaponWear = correctWeaponWear },
    engineHandlers = {
        onSave = function() return {version = 1, remainders = remainders} end,
        onLoad = function(data)
            remainders = data and data.remainders or {}
        end,
    },
}
