-- Real Combat prototype balance. Multipliers are relative to vanilla values.
-- Edit this file, then restart OpenMW. Keep skills in [skill.min, skill.max].
-- "Min"/"Max" mean the lowest/highest SKILL, not numerical ordering.
return {
    enabled = true,
    skill = { min = 0, max = 100 },
    weapon = {
        damageMin = 0.15, damageMax = 1.20,
        speedMin = 0.50, speedMax = 1.20,
        penetrationMin = 0.10, penetrationMax = 1.00,
        wearMin = 2.00, wearMax = 0.50,
        fatigueMin = 1.00, fatigueMax = 0.50,
    },
    exhaustion = {
        damage = 0.50,
        speed = 0.50,
        raiseSpeed = 0.50,
        shieldLeak = 0.50,
    },
    shield = {
        enabled = true,
        button = 3, -- SDL/OpenMW right mouse button; remap the vanilla menu action.
        raiseSecondsMin = 0.60, raiseSecondsMax = 0.20,
        wearMin = 2.00, wearMax = 0.50,
        fatigueMin = 1.00, fatigueMax = 0.50,
        wearBase = 1.00,
        fatigueBase = 1.00,
        heldLeak = 0.20,
        perfectSeconds = 1.00, -- Starts when the shield finishes rising.
        facingDegrees = 120, -- Total horizontal arc, centered on player facing.
        poseFraction = 0.50,
    },
    -- Morrowind's native critical is an unaware/sneak strike, not a random roll.
    -- Preserve it. The requested additional random critical can multiply an
    -- existing sneak critical; disable this section to retain only sneak crits.
    randomCrit = {
        enabled = true,
        chanceMin = 0.00, chanceMax = 0.10,
        multiplier = 0, -- Zero uses fCombatCriticalStrikeMult from the game.
    },
    accuracy = {
        enabled = true,
        bonus = 1000000, -- A dedicated Fortify Attack ability, active for melee only.
        allMeleeActors = true,
    },
    scope = {
        playerOnlySkillScaling = true,
    },
    npcBlock = {
        enabled = true, -- Recreate vanilla NPC block after native block is disabled.
    },
}
