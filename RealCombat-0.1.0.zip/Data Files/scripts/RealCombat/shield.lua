-- OpenMW 0.51 adapter for active blocking. Native random blocking must be
-- disabled by the companion LOAD script before this handler is used.
local State = require('scripts.RealCombat.shield_state')
local M = {}

function M.new(config, balance)
    local core = require('openmw.core')
    local input = require('openmw.input')
    local self = require('openmw.self')
    local types = require('openmw.types')
    local util = require('openmw.util')
    local animation = require('openmw.animation')
    local I = require('openmw.interfaces')
    local Actor, Armor, Weapon = types.Actor, types.Armor, types.Weapon
    local state = State.new()
    local poseActive, posePoint, warnedAnimation = false, nil, false
    local trackedShield, observedCondition, pendingWear = nil, 0, 0
    local heldShield = nil
    local attackAnimation = nil

    local oneHanded = {
        [Weapon.TYPE.ShortBladeOneHand] = true,
        [Weapon.TYPE.LongBladeOneHand] = true,
        [Weapon.TYPE.BluntOneHand] = true,
        [Weapon.TYPE.AxeOneHand] = true,
    }

    -- Releasing Use ends charging and starts the attack; it does not cancel it.
    -- Wait for that attack's follow-through before allowing a shield raise.
    I.AnimationController.addPlayBlendedAnimationHandler(function(group, options)
        local key = options.startKey or ''
        if key:match('^chop ') or key:match('^slash ') or key:match('^thrust ') then
            attackAnimation = { group = group, stopKey = options.stopKey or '' }
        elseif attackAnimation and attackAnimation.group == group then
            attackAnimation = nil
        end
    end)

    local function attacking()
        if not attackAnimation then return false end
        if not animation.hasAnimation(self) then return true end
        local completion = animation.getCompletion(self, attackAnimation.group)
        if completion == nil or (attackAnimation.stopKey:match(' follow stop$') and completion >= 1) then
            attackAnimation = nil
            return false
        end
        return true
    end

    -- Condition writes run in the global script. Account for queued writes so
    -- two attacks in one update cannot block with a shield already broken.
    local function effectiveCondition(shield)
        local condition = types.Item.itemData(shield).condition
        if trackedShield ~= shield then
            trackedShield, observedCondition, pendingWear = shield, condition, 0
        else
            pendingWear = math.max(0, pendingWear - math.max(0, observedCondition - condition))
            observedCondition = condition
        end
        return math.max(0, condition - pendingWear)
    end

    local function equippedShield()
        local shield = Actor.getEquipment(self, Actor.EQUIPMENT_SLOT.CarriedLeft)
        if not shield or not Armor.objectIsInstance(shield)
            or Armor.record(shield).type ~= Armor.TYPE.Shield then
            return nil
        end
        if effectiveCondition(shield) <= 0 then return nil end
        return shield
    end

    local function incapacitated()
        -- Public canMove also sees native knockdown before its animation begins.
        if not Actor.canMove(self) or Actor.isDead(self) or Actor.isSwimming(self) then return true end
        if Actor.activeEffects(self):getEffect(core.magic.EFFECT_TYPE.Paralyze).magnitude > 0 then
            return true
        end
        if animation.hasAnimation(self) then
            local group = animation.getActiveGroup(self, animation.BONE_GROUP.LowerBody) or ''
            if group:find('knockdown', 1, true) or group:find('knockout', 1, true)
                or group:match('^hit%d*$') or group:match('^swimhit%d*$') then
                return true
            end
        end
        return false
    end

    local function canRaise()
        if not config.enabled or not config.shield.enabled or I.UI.getMode() ~= nil or core.isWorldPaused()
            or Actor.getStance(self) ~= Actor.STANCE.Weapon or incapacitated() then
            return false
        end
        if not types.Player.getControlSwitch(self, types.Player.CONTROL_SWITCH.Controls)
            or not types.Player.getControlSwitch(self, types.Player.CONTROL_SWITCH.Fighting) then
            return false
        end
        local weapon = Actor.getEquipment(self, Actor.EQUIPMENT_SLOT.CarriedRight)
        if not weapon or not Weapon.objectIsInstance(weapon)
            or not oneHanded[Weapon.record(weapon).type] then
            return false
        end
        return equippedShield() ~= nil
    end

    local function stopPose()
        if poseActive and animation.hasAnimation(self) then
            animation.cancel(self, 'shield')
        end
        poseActive, posePoint = false, nil
    end

    local function showPose(progress)
        -- The stock shield track contains both raising and lowering. Scrub its
        -- first part and hold a configurable pose, instead of looping the recoil.
        local ok = animation.hasAnimation(self) and animation.hasGroup(self, 'shield')
            and animation.getTextKeyTime(self, 'shield: block start') ~= nil
            and animation.getTextKeyTime(self, 'shield: block stop') ~= nil
        if not ok then
            if not warnedAnimation then
                print('[RealCombat] Shield animation is unavailable; timed blocking remains active.')
                warnedAnimation = true
            end
            return
        end
        local point = math.min(0.99, math.max(0, config.shield.poseFraction * progress))
        if poseActive and posePoint == point and animation.isPlaying(self, 'shield') then return end
        -- Replaying an active group only changes priority in the engine;
        -- cancel first so startPoint actually moves to the requested pose.
        animation.cancel(self, 'shield')
        I.AnimationController.playBlendedAnimation('shield', {
            startKey = 'block start', stopKey = 'block stop',
            blendMask = animation.BLEND_MASK.LeftArm,
            priority = animation.PRIORITY.Block,
            autoDisable = false, speed = 0,
            startPoint = point,
        })
        poseActive, posePoint = true, point
    end

    local function reset()
        state.reset()
        heldShield = nil
        stopPose()
    end

    local function suppressAttack()
        if canRaise() and input.isMouseButtonPressed(config.shield.button) then
            self.controls.use = self.ATTACK_TYPE.NoAttack
        end
    end

    local function update(dt)
        if not canRaise() or not input.isMouseButtonPressed(config.shield.button) then
            reset()
            return
        end
        suppressAttack()
        if attacking() then
            reset()
            return
        end
        local shield = equippedShield()
        if heldShield and heldShield ~= shield then reset() end
        heldShield = shield
        local fatigue = Actor.stats.dynamic.fatigue(self).current
        local skill = types.NPC.stats.skills.block(self).modified
        local modifiers = balance.shieldModifiers(skill, fatigue <= 0, config)
        local current = state.update(dt, true, modifiers.raiseSeconds)
        suppressAttack()
        showPose(current.progress)
    end

    local function facing(attacker)
        if not attacker then return false end
        local delta = attacker.position - self.position
        local forward = self.rotation:apply(util.vector3(0, 1, 0))
        local distance = math.sqrt(delta.x * delta.x + delta.y * delta.y)
        local forwardLength = math.sqrt(forward.x * forward.x + forward.y * forward.y)
        if distance < 1e-6 or forwardLength < 1e-6 then return false end
        local cosine = (delta.x * forward.x + delta.y * forward.y) / (distance * forwardLength)
        return cosine >= math.cos(math.rad(config.shield.facingDegrees / 2))
    end

    local function staminaCost(attack, multiplier)
        local capacity = Actor.getCapacity(self)
        local encumbrance = capacity > 0 and math.min(1, Actor.getEncumbrance(self) / capacity) or 1
        local cost = core.getGMST('fFatigueBlockBase')
            + math.max(0, encumbrance) * core.getGMST('fFatigueBlockMult')
        if attack.weapon and Weapon.objectIsInstance(attack.weapon) then
            cost = cost + Weapon.record(attack.weapon).weight
                * math.min(1, math.max(0, attack.strength or 0))
                * core.getGMST('fWeaponFatigueBlockMult')
        end
        return math.max(0, cost * multiplier * config.shield.fatigueBase)
    end

    local function apply(attack)
        if not attack.successful or attack.sourceType ~= I.Combat.ATTACK_SOURCE_TYPES.Melee
            or not attack.damage or not canRaise() or attacking()
            or not input.isMouseButtonPressed(config.shield.button) then
            return nil
        end
        local current = state.snapshot()
        if not current.held or not current.ready or not facing(attack.attacker) then return nil end
        local shield = equippedShield()
        if shield ~= heldShield then return nil end
        local raw = math.max(0, attack.damage.health or 0) + math.max(0, attack.damage.fatigue or 0)
        if raw <= 0 then return nil end

        local fatigue = Actor.stats.dynamic.fatigue(self)
        local skill = types.NPC.stats.skills.block(self).modified
        local modifiers = balance.shieldModifiers(skill, fatigue.current <= 0, config)
        local cost = staminaCost(attack, modifiers.fatigue)
        -- Stop positive stamina at zero without healing pre-existing negative
        -- fatigue (for example, from an enemy's hand-to-hand attack).
        local remaining = math.min(fatigue.current, math.max(0, fatigue.current - cost))
        fatigue.current = remaining
        -- The hit that empties stamina also loses perfect-block protection.
        current.facing, current.exhausted = true, remaining <= 0
        local multiplier, reason = balance.blockMultiplier(current, config)
        local absorbed = raw * (1 - multiplier)
        attack.damage.health = (attack.damage.health or 0) * multiplier
        if attack.damage.fatigue then attack.damage.fatigue = attack.damage.fatigue * multiplier end
        attack._rcBlocked = true

        local wear = math.min(effectiveCondition(shield), math.max(0,
            absorbed * config.shield.wearBase * modifiers.wear))
        if wear > 0 then
            pendingWear = pendingWear + wear
            core.sendGlobalEvent('ModifyItemCondition', { actor = self, item = shield, amount = -wear })
        end
        if absorbed > 0 then
            I.SkillProgression.skillUsed('block', {
                useType = I.SkillProgression.SKILL_USE_TYPES.Block_Success,
            })
            local armorSkill = I.Combat.getArmorSkill(shield)
            local sound = armorSkill == 'heavyarmor' and 'Heavy Armor Hit'
                or armorSkill == 'mediumarmor' and 'Medium Armor Hit' or 'Light Armor Hit'
            core.sound.playSound3d(sound, self)
        end
        return { blocked = true, perfect = reason == 'perfect', reason = reason,
            multiplier = multiplier, absorbed = absorbed, fatigueCost = cost, wear = wear }
    end

    return {
        update = update, apply = apply, canRaise = canRaise,
        reset = reset, load = function() attackAnimation = nil; reset() end,
        suppressAttack = suppressAttack, state = state.snapshot,
    }
end

return M
