# Техническая основа

Цель: OpenMW **0.51.0**, официальный тег `openmw-0.51.0`, коммит
`f4bec41444214a7903bebd178389ca22ca13f646`. API проверены по исходникам этого
тега. Это проверка контрактов, не результат запуска игры.

| Задача | Реальный API / исходник OpenMW |
| --- | --- |
| Изменить урон до потери здоровья | [`Combat.addOnHitHandler`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/files/data/scripts/omw/combat/interface.lua) |
| Перехватить расчёт брони | [Реализация `Combat.applyArmor`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/files/data-mw/scripts/omw/combat/local.lua) и наследование интерфейса `Combat` |
| Порядок обработчиков | [`callEventHandlers`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/files/data/openmw_aux/util.lua) вызывает последний зарегистрированный обработчик первым |
| Скорость фаз атаки | [`AnimationController`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/files/data/scripts/omw/mechanics/animationcontroller.lua), `options.speed`, **`startKey` / `stopKey`** |
| Анимация щита | [`openmw.animation`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/files/lua_api/openmw/animation.lua): `cancel`, `playBlended`, `setSpeed` |
| Отключение раннего автоблока | [`LOAD / openmw.content`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/files/lua_api/openmw/content.lua): `gameSettings.records` |
| Служебная способность точности | `content.spells.records`, затем [`Actor.spells:add/remove`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/files/lua_api/openmw/types.lua) |
| Износ предметов | `Item.itemData(item).condition` в глобальном контексте; [`ModifyItemCondition`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/files/data/scripts/omw/mechanics/globalcontroller.lua) |
| ПКМ | [`input.isMouseButtonPressed(3)`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/files/lua_api/openmw/input.lua) |

## Порядок обработки

Движок по-прежнему определяет физический контакт и проверяет дальность. Его
[`Npc::hit`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/apps/openmw/mwclass/npc.cpp)
вычитает стамину и износ, применяет сопротивления, обычный скрытный крит,
зачарования и проверку штатного блока **до** Lua-события `Hit`.

Поэтому Real Combat:

1. Даёт отдельную способность Fortify Attack во время стойки ближнего боя.
   Она предотвращает штатные промахи при обычных характеристиках игры.
   Одна лишь подмена `attack.successful` после промаха не сохранила бы
   зачарования и опыт; мод намеренно не делает такой подмены.
2. Отключает штатную случайную проверку блока при загрузке, сохраняя её
   численные границы для приближённого NPC-блока на Lua.
3. Умножает входящий пакет оружейного урона на коэффициент навыка и,
   если выпал, случайный крит. Отдельно отмечает пробитие брони.
4. Обрабатывает активный щит до передачи пакета штатному обработчику.
   Доля урона щита применяется **после** нелинейного расчёта брони,
   а затем штатный обработчик применяет сложность и сам урон.

## Стамина и износ

Сила взмаха восстанавливается из `startPoint` и ключей стандартной анимации
обратно к формуле [`CharacterController`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/apps/openmw/mwmechanics/character.cpp).
Событие ключа `chop/slash/thrust hit` учитывает также взмах в воздух.
Один взмах получает только один возврат лишней стамины. Поскольку `Hit`
обрабатывается раньше Lua-ключей анимации, при проверке истощения для урона
учитывается ещё не обработанный возврат за этот удар.

Износ пересчитывается по исходной прочности перед контактом и формуле
[`combat.cpp`](https://github.com/OpenMW/openmw/blob/openmw-0.51.0/apps/openmw/mwmechanics/combat.cpp).
Глобальный обработчик применяет только разницу относительно штатного износа.
Дробная часть сохраняется отдельно для каждого оружия: при цене 0,5 пункта
два удара расходуют один целый пункт. Если движок преждевременно снял оружие
с последним пунктом прочности, мод восстанавливает его только в пустую руку.
Коррекция проходит через очередь событий; кратковременное снятие оружия
на границе поломки остаётся особенностью прототипа.

При нестандартных анимациях, нескольких ударах одним взмахом или изменении
нативных правил другим боевым модом требуется отдельная проверка. Будущая
версия может использовать более ранние боевые хуки движка, когда они появятся.
