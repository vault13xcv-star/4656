---
-- Defines functions and types that are available in local, global, menu, and load scripts.
-- @context global|menu|local|player|load
-- @module core
-- @usage local core = require('openmw.core')



---
-- The revision of OpenMW's Lua API. It is an integer that is incremented every time the API is changed. See the actual value at the top of the page.
-- @field [parent=#core] #number API_REVISION

---
-- Terminates the game and quits to the OS. Should be used only for testing purposes. Not available in load scripts.
-- @function [parent=#core] quit

---
-- Send an event to global scripts. Note: in menu scripts, errors if the game is not running (check @{openmw.menu#menu.getState}.) Not available in load scripts.
-- @function [parent=#core] sendGlobalEvent
-- @param #string eventName
-- @param eventData

---
-- Simulation time in seconds.
-- The number of simulation seconds passed in the game world since starting a new game. Not available in load scripts.
-- @function [parent=#core] getSimulationTime
-- @return #number

---
-- The scale of simulation time relative to real time. Not available in load scripts.
-- @function [parent=#core] getSimulationTimeScale
-- @return #number

---
-- Game time in seconds. Not available in load scripts.
-- @function [parent=#core] getGameTime
-- @return #number

---
-- The scale of game time relative to simulation time. Not available in load scripts.
-- @function [parent=#core] getGameTimeScale
-- @return #number

---
-- Whether the world is paused. Not available in load scripts.
-- @function [parent=#core] isWorldPaused
-- @return #boolean

---
-- Real time in seconds; starting point is not fixed (can be time since last reboot), use only for measuring intervals. For Unix time use `os.time()`. Not available in load scripts.
-- @function [parent=#core] getRealTime
-- @return #number

---
-- Frame duration in seconds. Not available in global or load scripts.
-- @function [parent=#core] getRealFrameDuration
-- @return #number

---
-- Get a game setting with given name (from GMST ESM records or from openmw.cfg). Not available in load scripts.
-- @function [parent=#core] getGMST
-- @param #string setting Setting name
-- @return #any
-- @usage local skillBonus = core.getGMST('fMinorSkillBonus') -- get a numeric GMST from ESM data
-- @usage local jailFormatString = core.getGMST('sNotifyMessage42') -- get a string GMST from ESM data
-- @usage local bloodTextureName = core.getGMST('Blood_Texture_1') -- get a "fallback" parameter value from openmw.cfg (always a string)

---
-- The game's difficulty setting.
-- @function [parent=#core] getGameDifficulty
-- @return #number

---
-- Return l10n formatting function for the given context.
-- Localisation files (containing the message names and translations) should be stored in
-- VFS as files of the form `l10n/<ContextName>/<Locale>.yaml`.
--
-- See [Localisation](../modding/localisation.html) for details of the localisation file structure.
--
-- When calling the l10n formatting function, if no localisation can be found for any of the requested locales then
-- the message key will be returned instead (and formatted, if possible).
-- This makes it possible to use the source strings as message identifiers.
--
-- If you do not use the source string as a message identifier you should instead make certain to include
-- a fallback locale with a complete set of messages.
--
-- @function [parent=#core] l10n
-- @param #string context l10n context; recommended to use the name of the mod.
--                This must match the <ContextName> directory in the VFS which stores the localisation files.
-- @param #string fallbackLocale The source locale containing the default messages
--                               If omitted defaults to "en".
-- @return #function
-- @usage
-- # DataFiles/l10n/MyMod/en.yaml
-- good_morning: 'Good morning.'
-- you_have_arrows: |-
--   {count, plural,
--     one {You have one arrow.}
--     other {You have {count} arrows.}
--   }
-- @usage
-- # DataFiles/l10n/MyMod/de.yaml
-- good_morning: "Guten Morgen."
-- you_have_arrows: |-
--   {count, plural,
--     one {Du hast ein Pfeil.}
--     other {Du hast {count} Pfeile.}
--   }
-- "Hello {name}!": "Hallo {name}!"
-- @usage
-- -- Usage in Lua
-- local myMsg = core.l10n('MyMod', 'en')
-- print( myMsg('good_morning') )
-- print( myMsg('you_have_arrows', {count=5}) )
-- print( myMsg('Hello {name}!', {name='World'}) )


---
-- @{#ContentFiles}: functions working with the list of currently loaded content files.
-- @field [parent=#core] #ContentFiles contentFiles

---
-- Functions working with the list of currently loaded content files.
-- @type ContentFiles
-- @field #list<#string> list The current load order (list of content file names).

---
-- Return the index of a specific content file in the load order (or `nil` if there is no such content file).
-- @function [parent=#ContentFiles] indexOf
-- @param #string contentFile
-- @return #number

---
-- Check if the content file with given name present in the load order.
-- @function [parent=#ContentFiles] has
-- @param #string contentFile
-- @return #boolean

---
-- Construct FormId string from content file name and the index in the file.
-- In ESM3 games (e.g. Morrowind) FormIds are used to reference game objects.
-- In ESM4 games (e.g. Skyrim) FormIds are used both for game objects and as record ids.
-- @function [parent=#core] getFormId
-- @param #string contentFile
-- @param #number index
-- @return #string
-- @usage if obj.recordId == core.getFormId('Skyrim.esm', 0x4d7da) then ... end
-- @usage -- In ESM3 content files (e.g. Morrowind) ids are human-readable strings
-- obj.owner.factionId = 'blades'
-- -- In ESM4 (e.g. Skyrim) ids should be constructed using `core.getFormId`:
-- obj.owner.factionId = core.getFormId('Skyrim.esm', 0x72834)
-- @usage -- local scripts
-- local obj = nearby.getObjectByFormId(core.getFormId('Morrowind.esm', 128964))
-- @usage -- global scripts
-- local obj = world.getObjectByFormId(core.getFormId('Morrowind.esm', 128964))


---
-- Any object that exists in the game world and has a specific location.
-- Player, actors, items, and statics are game objects.
-- @type GameObject
-- @extends #userdata
-- @field #string id The unique id of this object (not record id), can be used as a key in a table.
-- @field #string contentFile Lowercase file name of the content file that defines this object; nil for dynamically created objects.
-- @field #boolean enabled Whether the object is enabled or disabled. Global scripts can set the value. Items in containers or inventories can't be disabled.
-- @field openmw.util#Vector3 position Object position.
-- @field #number scale Object scale.
-- @field openmw.util#Transform rotation Object rotation.
-- @field #Cell startingCell The object's original cell. Returns nil if `cell` of the object is nil.
-- @field openmw.util#Vector3 startingPosition The object original position
-- @field openmw.util#Transform startingRotation The object original rotation
-- @field #ObjectOwner owner Ownership information
-- @field #Cell cell The cell where the object currently is. During loading a game and for objects in an inventory or a container `cell` is nil.
-- @field #GameObject parentContainer Container or actor that contains (or has in inventory) this object. It is nil if the object is in a cell.
-- @field #any type Type of the object (one of the tables from the package @{openmw.types#types}).
-- @field #number count Count (>1 means a stack of objects).
-- @field #string recordId Returns record ID of the object in lowercase.
-- @field #string globalVariable Global Variable associated with this object (read only).


---
-- Object owner information
-- @type ObjectOwner
-- @field #string recordId NPC who owns the object (nil if missing). Global and self scripts can set the value.
-- @field #string factionId Faction who owns the object (nil if missing). Global and self scripts can set the value.
-- @field #number factionRank Rank required to be allowed to pick up the object (`nil` if any rank is allowed). Global and self scripts can set the value.

---
-- Does the object still exist and is available.
-- Returns true if the object exists and loaded, and false otherwise. If false, then every
-- access to the object will raise an error.
-- @function [parent=#GameObject] isValid
-- @param self
-- @return #boolean

---
-- Send a local event to the object.
-- @function [parent=#GameObject] sendEvent
-- @param self
-- @param #string eventName
-- @param eventData

---
-- Activate the object.
-- @function [parent=#GameObject] activateBy
-- @param self
-- @param #GameObject actor The actor who activates the object
-- @usage local self = require('openmw.self')
-- object:activateBy(self)

---
-- Add a new local script to the object.
-- Can be called only from a global script. Script should be specified in a content
-- file (omwgame/omwaddon/omwscripts) with a CUSTOM flag. Scripts can not be attached to Statics.
-- @function [parent=#GameObject] addScript
-- @param self
-- @param #string scriptPath Path to the script in OpenMW virtual filesystem.
-- @param #table initData (optional) Initialization data to be passed to onInit. If missed then Lua initialization data from content files will be used (if exists for this script).

---
-- Whether a script with given path is attached to this object.
-- Can be called only from a global script.
-- @function [parent=#GameObject] hasScript
-- @param self
-- @param #string scriptPath Path to the script in OpenMW virtual filesystem.
-- @return #boolean

---
-- Removes script that was attached by `addScript`
-- Can be called only from a global script.
-- @function [parent=#GameObject] removeScript
-- @param self
-- @param #string scriptPath Path to the script in OpenMW virtual filesystem.

---
-- Sets the object's scale.
-- Can be called only from a global script.
-- @function [parent=#GameObject] setScale
-- @param self
-- @param #number scale Scale desired in game.

---
-- Moves the object to given cell and position.
-- Can be called only from a global script.
-- The effect is not immediate: the position will be updated only in the next
-- frame. Can be called only from a global script. Enables object if it was disabled.
-- Can be used to move objects from an inventory or a container to the world.
-- @function [parent=#GameObject] teleport
-- @param self
-- @param #any cellOrName A cell to define the destination worldspace; can be either @{#Cell}, or cell name, or an empty string (empty string means the default exterior worldspace).
-- If the worldspace has multiple cells (i.e. an exterior), the destination cell is calculated using `position`.
-- @param openmw.util#Vector3 position New position.
-- @param #TeleportOptions options (optional) Either table @{#TeleportOptions} or @{openmw.util#Transform} rotation.

---
-- Either a table with options or a @{openmw.util#Vector3} rotation.
-- @type TeleportOptions
-- @field openmw.util#Transform rotation New rotation; if missing, then the current rotation is used.
-- @field #boolean onGround If true, adjust destination position to the ground.

---
-- Moves an object into a container or an inventory. Enables if was disabled.
-- Can be called only from a global script.
-- @function [parent=#GameObject] moveInto
-- @param self
-- @param #any dest @{#Inventory} or @{#GameObject}
-- @usage item:moveInto(types.Actor.inventory(actor))
-- @usage item:moveInto(types.Container.content(container))
-- @usage item:moveInto(container)

---
-- Removes an object or reduces a stack of objects.
-- Can be called only from a global script.
-- @function [parent=#GameObject] remove
-- @param self
-- @param #number count (optional) the number of items to remove (if not specified then the whole stack)

---
-- Splits a stack of items. Original stack is reduced by `count`. Returns a new stack with `count` items.
-- Can be called only from a global script.
-- @function [parent=#GameObject] split
-- @param self
-- @param #number count The number of items to return.
-- @return #GameObject
-- @usage -- take 50 coins from `money` and put to the container `cont`
-- money:split(50):moveInto(types.Container.content(cont))

---
-- The axis aligned bounding box in world coordinates.
-- @function [parent=#GameObject] getBoundingBox
-- @param self
-- @return openmw.util#Box

---
-- List of GameObjects. Implements [iterables#List](iterables.html#List) of #GameObject
-- @type ObjectList
-- @list <#GameObject>


---
-- A cell of the game world.
-- @type Cell
-- @field #string name Name of the cell (can be empty string).
-- @field #string displayName Human-readable cell name (takes into account *.cel file localizations). Can be an empty string.
-- @field #string id Unique record ID of the cell, based on cell name for interiors and the worldspace for exteriors, or the formID of the cell for ESM4 cells.
-- @field #string region Region of the cell (can be nil).
-- @field #boolean isExterior Whether the cell is an exterior cell. "Exterior" means grid of cells where the player can seamless walk from one cell to another without teleports. QuasiExterior (interior with sky) is not an exterior.
-- @field #boolean isQuasiExterior (DEPRECATED, use `hasTag("QuasiExterior")`) Whether the cell is a quasi exterior (like interior but with the sky and the weather).
-- @field #number gridX Index of the cell by X (only for exteriors).
-- @field #number gridY Index of the cell by Y (only for exteriors).
-- @field #string worldSpaceId Id of the world space (can be nil).
-- @field #boolean hasWater True if the cell contains water.
-- @field #number waterLevel The water level of the cell. (nil if cell has no water).
-- @field #boolean hasSky True if in this cell sky should be rendered.
-- @field #PathGrid pathGrid The cell's @{#PathGrid} if it has one.

---
-- Returns true if the cell has given tag.
-- @function [parent=#Cell] hasTag
-- @param self
-- @param #string tag One of "QuasiExterior", "NoSleep".
-- @return #boolean

---
-- Returns true either if the cell contains the object or if the cell is an exterior and the object is also in an exterior.
-- @function [parent=#Cell] isInSameSpace
-- @param self
-- @param #GameObject object
-- @return #boolean
-- @usage
-- if obj1.cell:isInSameSpace(obj2) then
--     dist = (obj1.position - obj2.position):length()
-- else
--     -- the distance can't be calculated because the coordinates are in different spaces
-- end

---
-- Get all objects of given type from the cell; Only available from global scripts.
-- @function [parent=#Cell] getAll
-- @param self
-- @param type (optional) object type (see @{openmw.types#types})
-- @return #ObjectList
-- @usage
-- local type = require('openmw.types')
-- local all = cell:getAll()
-- local weapons = cell:getAll(types.Weapon)

---
-- A cell's path grid marking traversable paths.
-- @type PathGrid

---
-- Get all points in this path grid.
-- @function [parent=#PathGrid] getPoints
-- @param self
-- @return #list<#PathGridPoint> A list of @{#PathGridPoint}s.

---
-- A point in a cell's path grid.
-- @type PathGridPoint
-- @field #boolean autoGenerated True if this node was automatically generated in the editor.
-- @field openmw.util#Vector3 relativePosition The point's position relative to the cell's origin. An exterior cell's origin is its southwest corner.
-- @field #list<#PathGridPoint> connections A list of points connected to this point.

---
-- @type ActiveSpell
-- @field #string name The spell or item display name
-- @field #string id Record id of the spell or item used to cast the spell
-- @field #GameObject item The enchanted item used to cast the spell, or nil if the spell was not cast from an enchanted item. Note that if the spell was cast for a single-use enchantment such as a scroll, this will be nil.
-- @field #GameObject caster The caster object, or nil if the spell has no defined caster
-- @field #boolean fromEquipment If set, this spell is tied to an equipped item and can only be ended by unequipping the item.
-- @field #boolean temporary If set, this spell effect is temporary and should end on its own. Either after a single application or after its duration has run out.
-- @field #boolean affectsBaseValues If set, this spell affects the base values of affected stats, rather than modifying current values.
-- @field #boolean stackable If set, this spell can be applied multiple times. If not set, the same spell can only be applied once from the same source (where source is determined by caster + item). In vanilla rules, consumables are stackable while spells and enchantments are not.
-- @field #string activeSpellId Uniquely identifies this active spell within the affected actor's list of active spells.
-- @field #list<#ActiveSpellEffect> effects The active effects (@{#ActiveSpellEffect}) of this spell.

---
-- @type ActiveSpellEffect
-- @field #number index Index of this effect within the original list of @{#MagicEffectWithParams} of the spell/enchantment/potion this effect came from.
-- @field #string affectedSkill Optional skill ID
-- @field #string affectedAttribute Optional attribute ID
-- @field #string id Magic effect id
-- @field #string name Localized name of the effect
-- @field #number magnitudeThisFrame The magnitude of the effect in the current frame. This will be a new random number between minMagnitude and maxMagnitude every frame. Or nil if the effect has no magnitude.
-- @field #number minMagnitude The minimum magnitude of this effect, or nil if the effect has no magnitude.
-- @field #number maxMagnitude The maximum magnitude of this effect, or nil if the effect has no magnitude.
-- @field #number duration Total duration in seconds of this spell effect, should not be confused with remaining duration. Or nil if the effect is not temporary.
-- @field #number durationLeft Remaining duration in seconds of this spell effect, or nil if the effect is not temporary.


--- Possible @{#EnchantmentType} values
-- @field [parent=#Magic] #EnchantmentType ENCHANTMENT_TYPE

--- `core.magic.ENCHANTMENT_TYPE`
-- @type EnchantmentType
-- @field #number CastOnce Enchantment can be cast once, destroying the enchanted item.
-- @field #number CastOnStrike Enchantment is cast on strike, if there is enough charge.
-- @field #number CastOnUse Enchantment is cast when used, if there is enough charge.
-- @field #number ConstantEffect Enchantment is always active when equipped.


---
-- @type Enchantment
-- @field #string id Enchantment id
-- @field #number type @{#EnchantmentType}
-- @field #boolean autocalcFlag (DEPRECATED, use isAutocalc) If set, the casting cost should be computed based on the effect list rather than read from the cost field
-- @field #boolean isAutocalc If set, the casting cost should be computed based on the effect list rather than read from the cost field
-- @field #number cost
-- @field #number charge Charge capacity. Should not be confused with current charge.
-- @field #list<#MagicEffectWithParams> effects The effects (@{#MagicEffectWithParams}) of the enchantment
-- @usage -- Getting the enchantment of an arbitrary item, if it has one
-- local function getRecord(item)
--     if item.type and item.type.record then
--         return item.type.record(item)
--     end
--     return nil
-- end
-- local function getEnchantment(item)
--     local record = getRecord(item)
--     if record and record.enchant then
--         return core.magic.enchantments.records[record.enchant]
--     end
--     return nil
-- end


---
-- Inventory of a player/NPC or a content of a container.
-- @type Inventory

---
-- The number of items with the given recordId.
-- @function [parent=#Inventory] countOf
-- @param self
-- @param #string recordId
-- @return #number

---
-- Get all items of the given type from the inventory.
-- @function [parent=#Inventory] getAll
-- @param self
-- @param type (optional) items type (see @{openmw.types#types})
-- @return #ObjectList
-- @usage
-- local types = require('openmw.types')
-- local self = require('openmw.self')
-- local playerInventory = types.Actor.inventory(self.object)
-- local all = playerInventory:getAll()
-- local weapons = playerInventory:getAll(types.Weapon)

---
-- Get first item with the given recordId from the inventory. Returns nil if not found.
-- @function [parent=#Inventory] find
-- @param self
-- @param #string recordId
-- @return #GameObject
-- @usage inventory:find('gold_001')

---
-- Will resolve the inventory, filling it with levelled items if applicable, making its contents permanent. Must be used in a global script.
-- @function [parent=#Inventory] resolve
-- @param self
-- @usage inventory:resolve()

---
-- Checks if the inventory has a resolved item list.
-- @function [parent=#Inventory] isResolved
-- @param self
-- @return #boolean
-- @usage inventory:isResolved()

---
-- Get all items with the given recordId from the inventory.
-- @function [parent=#Inventory] findAll
-- @param self
-- @param #string recordId
-- @return #ObjectList
-- @usage for _, item in ipairs(inventory:findAll('common_shirt_01')) do ... end


--- @{#Land}: Functions for interacting with land data. Not available in load scripts.
-- @field [parent=#core] #Land land

---
-- Get the terrain height at a given location.
-- @function [parent=#Land] getHeightAt
-- @param openmw.util#Vector3 position
-- @param #any cellOrId cell or cell id in their exterior world space to query
-- @return #number

---
-- Get the terrain texture at a given location. As textures are blended and
-- multiple textures can be at one specific position the texture whose center is
-- closest to the position will be returned.
--
-- @function [parent=#Land] getTextureAt
-- @param openmw.util#Vector3 position
-- @param #any cellOrId cell or cell id in their exterior world space to query
-- @return #nil, #string Texture path or nil if one isn't defined
-- @return #nil, #string Plugin name or nil if failed to retrieve the texture


--- @{#Magic}: spells and spell effects. Not available in load scripts.
-- @field [parent=#core] #Magic magic


--- Possible @{#SpellRange} values
-- @field [parent=#Magic] #SpellRange RANGE

--- `core.magic.RANGE`
-- @type SpellRange
-- @field #number Self Applied on self
-- @field #number Touch On touch
-- @field #number Target Ranged spell


--- Possible @{#MagicEffectId} values
-- @field [parent=#Magic] #MagicEffectId EFFECT_TYPE

--- `core.magic.EFFECT_TYPE`
-- @type MagicEffectId
-- @field #number WaterBreathing "waterbreathing"
-- @field #number SwiftSwim "swiftswim"
-- @field #number WaterWalking "waterwalking"
-- @field #number Shield "shield"
-- @field #number FireShield "fireshield"
-- @field #number LightningShield "lightningshield"
-- @field #number FrostShield "frostshield"
-- @field #number Burden "burden"
-- @field #number Feather "feather"
-- @field #number Jump "jump"
-- @field #number Levitate "levitate"
-- @field #number SlowFall "slowfall"
-- @field #number Lock "lock"
-- @field #number Open "open"
-- @field #number FireDamage "firedamage"
-- @field #number ShockDamage "shockdamage"
-- @field #number FrostDamage "frostdamage"
-- @field #number DrainAttribute "drainattribute"
-- @field #number DrainHealth "drainhealth"
-- @field #number DrainMagicka "drainmagicka"
-- @field #number DrainFatigue "drainfatigue"
-- @field #number DrainSkill "drainskill"
-- @field #number DamageAttribute "damageattribute"
-- @field #number DamageHealth "damagehealth"
-- @field #number DamageMagicka "damagemagicka"
-- @field #number DamageFatigue "damagefatigue"
-- @field #number DamageSkill "damageskill"
-- @field #number Poison "poison"
-- @field #number WeaknessToFire "weaknesstofire"
-- @field #number WeaknessToFrost "weaknesstofrost"
-- @field #number WeaknessToShock "weaknesstoshock"
-- @field #number WeaknessToMagicka "weaknesstomagicka"
-- @field #number WeaknessToCommonDisease "weaknesstocommondisease"
-- @field #number WeaknessToBlightDisease "weaknesstoblightdisease"
-- @field #number WeaknessToCorprusDisease "weaknesstocorprusdisease"
-- @field #number WeaknessToPoison "weaknesstopoison"
-- @field #number WeaknessToNormalWeapons "weaknesstonormalweapons"
-- @field #number DisintegrateWeapon "disintegrateweapon"
-- @field #number DisintegrateArmor "disintegratearmor"
-- @field #number Invisibility "invisibility"
-- @field #number Chameleon "chameleon"
-- @field #number Light "light"
-- @field #number Sanctuary "sanctuary"
-- @field #number NightEye "nighteye"
-- @field #number Charm "charm"
-- @field #number Paralyze "paralyze"
-- @field #number Silence "silence"
-- @field #number Blind "blind"
-- @field #number Sound "sound"
-- @field #number CalmHumanoid "calmhumanoid"
-- @field #number CalmCreature "calmcreature"
-- @field #number FrenzyHumanoid "frenzyhumanoid"
-- @field #number FrenzyCreature "frenzycreature"
-- @field #number DemoralizeHumanoid "demoralizehumanoid"
-- @field #number DemoralizeCreature "demoralizecreature"
-- @field #number RallyHumanoid "rallyhumanoid"
-- @field #number RallyCreature "rallycreature"
-- @field #number Dispel "dispel"
-- @field #number Soultrap "soultrap"
-- @field #number Telekinesis "telekinesis"
-- @field #number Mark "mark"
-- @field #number Recall "recall"
-- @field #number DivineIntervention "divineintervention"
-- @field #number AlmsiviIntervention "almsiviintervention"
-- @field #number DetectAnimal "detectanimal"
-- @field #number DetectEnchantment "detectenchantment"
-- @field #number DetectKey "detectkey"
-- @field #number SpellAbsorption "spellabsorption"
-- @field #number Reflect "reflect"
-- @field #number CureCommonDisease "curecommondisease"
-- @field #number CureBlightDisease "cureblightdisease"
-- @field #number CureCorprusDisease "curecorprusdisease"
-- @field #number CurePoison "curepoison"
-- @field #number CureParalyzation "cureparalyzation"
-- @field #number RestoreAttribute "restoreattribute"
-- @field #number RestoreHealth "restorehealth"
-- @field #number RestoreMagicka "restoremagicka"
-- @field #number RestoreFatigue "restorefatigue"
-- @field #number RestoreSkill "restoreskill"
-- @field #number FortifyAttribute "fortifyattribute"
-- @field #number FortifyHealth "fortifyhealth"
-- @field #number FortifyMagicka "fortifymagicka"
-- @field #number FortifyFatigue "fortifyfatigue"
-- @field #number FortifySkill "fortifyskill"
-- @field #number FortifyMaximumMagicka "fortifymaximummagicka"
-- @field #number AbsorbAttribute "absorbattribute"
-- @field #number AbsorbHealth "absorbhealth"
-- @field #number AbsorbMagicka "absorbmagicka"
-- @field #number AbsorbFatigue "absorbfatigue"
-- @field #number AbsorbSkill "absorbskill"
-- @field #number ResistFire "resistfire"
-- @field #number ResistFrost "resistfrost"
-- @field #number ResistShock "resistshock"
-- @field #number ResistMagicka "resistmagicka"
-- @field #number ResistCommonDisease "resistcommondisease"
-- @field #number ResistBlightDisease "resistblightdisease"
-- @field #number ResistCorprusDisease "resistcorprusdisease"
-- @field #number ResistPoison "resistpoison"
-- @field #number ResistNormalWeapons "resistnormalweapons"
-- @field #number ResistParalysis "resistparalysis"
-- @field #number RemoveCurse "removecurse"
-- @field #number TurnUndead "turnundead"
-- @field #number SummonScamp "summonscamp"
-- @field #number SummonClannfear "summonclannfear"
-- @field #number SummonDaedroth "summondaedroth"
-- @field #number SummonDremora "summondremora"
-- @field #number SummonAncestralGhost "summonancestralghost"
-- @field #number SummonSkeletalMinion "summonskeletalminion"
-- @field #number SummonBonewalker "summonbonewalker"
-- @field #number SummonGreaterBonewalker "summongreaterbonewalker"
-- @field #number SummonBonelord "summonbonelord"
-- @field #number SummonWingedTwilight "summonwingedtwilight"
-- @field #number SummonHunger "summonhunger"
-- @field #number SummonGoldenSaint "summongoldensaint"
-- @field #number SummonFlameAtronach "summonflameatronach"
-- @field #number SummonFrostAtronach "summonfrostatronach"
-- @field #number SummonStormAtronach "summonstormatronach"
-- @field #number FortifyAttack "fortifyattack"
-- @field #number CommandCreature "commandcreature"
-- @field #number CommandHumanoid "commandhumanoid"
-- @field #number BoundDagger "bounddagger"
-- @field #number BoundLongsword "boundlongsword"
-- @field #number BoundMace "boundmace"
-- @field #number BoundBattleAxe "boundbattleaxe"
-- @field #number BoundSpear "boundspear"
-- @field #number BoundLongbow "boundlongbow"
-- @field #number ExtraSpell "extraspell"
-- @field #number BoundCuirass "boundcuirass"
-- @field #number BoundHelm "boundhelm"
-- @field #number BoundBoots "boundboots"
-- @field #number BoundShield "boundshield"
-- @field #number BoundGloves "boundgloves"
-- @field #number Corprus "corprus"
-- @field #number Vampirism "vampirism"
-- @field #number SummonCenturionSphere "summoncenturionsphere"
-- @field #number SunDamage "sundamage"
-- @field #number StuntedMagicka "stuntedmagicka"
-- @field #number SummonFabricant "summonfabricant"
-- @field #number SummonWolf "summonwolf"
-- @field #number SummonBear "summonbear"
-- @field #number SummonBonewolf "summonbonewolf"
-- @field #number SummonCreature04 "summoncreature04"
-- @field #number SummonCreature05 "summoncreature05"

--- Possible @{#SpellType} values
-- @field [parent=#Magic] #SpellType SPELL_TYPE

--- `core.magic.SPELL_TYPE`
-- @type SpellType
-- @field #number Spell Normal spell, must be cast and costs mana
-- @field #number Ability Innate ability, always in effect
-- @field #number Blight Blight disease
-- @field #number Disease Common disease
-- @field #number Curse Curse
-- @field #number Power Power, can be used once a day

--- @{#Spells}: Spells
-- @field [parent=#Magic] #Spells spells

---
-- Creates a @{#Spell} without adding it to the world database.
-- Use @{openmw_world#(world).createRecord} to add the record to the world.
-- @function [parent=#Spells] createRecordDraft
-- @param #Spell spell A Lua table with the fields of a Spell, with an optional field `template` that accepts a @{#Spell} as a base.
-- @return #Spell A strongly typed Spell record.

--- List of all @{#Spell}s.
-- @field [parent=#Spells] #list<#Spell> records A read-only list of all @{#Spell} records in the world database, may be indexed by recordId.
-- Implements [iterables#List](iterables.html#List) of #Spell.
-- @usage local spell = core.magic.spells.records['thunder fist']  -- get by id
-- @usage local spell = core.magic.spells.records[1]  -- get by index
-- @usage -- Print all powers
-- for _, spell in pairs(core.magic.spells.records) do
--     if spell.type == core.magic.SPELL_TYPE.Power then
--         print(spell.name)
--     end
-- end

--- @{#Effects}: Magic Effects
-- @field [parent=#Magic] #Effects effects

--- Map from @{#MagicEffectId} to @{#MagicEffect}
-- @field [parent=#Effects] #map<#number, #MagicEffect> records
-- @usage -- Print all harmful effects
-- for _, effect in pairs(core.magic.effects.records) do
--     if effect.harmful then
--         print(effect.name)
--     end
-- end
-- @usage -- Look up the record of a specific effect and print its icon
-- local mgef = core.magic.effects.records[core.magic.EFFECT_TYPE.Reflect]
-- print('Reflect Icon: '..tostring(mgef.icon))

--- @{#Enchantments}: Enchantments
-- @field [parent=#Magic] #Enchantments enchantments

---
-- Creates an @{#Enchantment} without adding it to the world database.
-- Use @{openmw_world#(world).createRecord} to add the record to the world.
-- @function [parent=#Enchantments] createRecordDraft
-- @param #Enchantment enchantment A Lua table with the fields of an Enchantment, with an optional field `template` that accepts an @{#Enchantment} as a base.
-- @return #Enchantment A strongly typed Enchantment record.

--- A read-only list of all @{#Enchantment} records in the world database, may be indexed by recordId.
-- Implements [iterables#List](iterables.html#List) and [iterables#Map](iterables.html#map-iterable) of #Enchantment.
-- @field [parent=#Enchantments] #list<#Enchantment> records
-- @usage local enchantment = core.magic.enchantments.records['marara's boon']  -- get by id
-- @usage local enchantment = core.magic.enchantments.records[1]  -- get by index
-- @usage -- Print all enchantments with constant effect
-- for _, ench in pairs(core.magic.enchantments.records) do
--     if ench.type == core.magic.ENCHANTMENT_TYPE.ConstantEffect then
--         print(ench.id)
--     end
-- end


---
-- @type Spell
-- @field #string id Spell id
-- @field #string name Spell name
-- @field #number type @{#SpellType}
-- @field #number cost
-- @field #list<#MagicEffectWithParams> effects The effects (@{#MagicEffectWithParams}) of the spell
-- @field #boolean alwaysSucceedFlag If set, the spell should ignore skill checks and always succeed.
-- @field #boolean starterSpellFlag If set, the spell can be selected as a player's starting spell.
-- @field #boolean autocalcFlag (DEPRECATED, use isAutocalc) If set, the casting cost should be computed based on the effect list rather than read from the cost field
-- @field #boolean isAutocalc If set, the casting cost should be computed based on the effect list rather than read from the cost field

---
-- @type MagicEffect
-- @field #string id Effect ID
-- @field #string icon Effect Icon Path
-- @field #string name Localized name of the effect
-- @field #string description Localized description of the effect
-- @field #string school Skill ID that is this effect's school
-- @field #number baseCost
-- @field openmw.util#Color color
-- @field #boolean harmful If set, the effect is considered harmful and should elicit a hostile reaction from affected NPCs.
-- @field #boolean continuousVfx Whether the magic effect's vfx should loop or not
-- @field #boolean hasDuration If set, the magic effect has a duration. As an example, divine intervention has no duration while fire damage does.
-- @field #boolean hasMagnitude If set, the magic effect depends on a magnitude. As an example, cure common disease has no magnitude while chameleon does.
-- @field #boolean isAppliedOnce If set, the magic effect is applied fully on cast, rather than being continuously applied over the effect's duration. For example, chameleon is applied once, while fire damage is continuously applied for the duration.
-- @field #boolean casterLinked If set, it is implied the magic effect links back to the caster in some way and should end immediately or never be applied if the caster dies or is not an actor.
-- @field #boolean nonRecastable If set, this effect cannot be re-applied until it has ended. This is used by bound equipment spells.
-- @field #string particle Identifier of the particle texture
-- @field #string castStatic Identifier of the vfx static used for casting
-- @field #string hitStatic Identifier of the vfx static used on hit
-- @field #string areaStatic Identifier of the vfx static used for AOE spells
-- @field #string bolt Identifier of the projectile used for ranged spells
-- @field #string castSound Identifier of the sound used for casting
-- @field #string hitSound Identifier of the sound used on hit
-- @field #string areaSound Identifier of the sound used for AOE spells
-- @field #string boltSound Identifier of the projectile sound used for ranged spells
-- @field #boolean hasAttribute True if the effect requires an attribute parameter
-- @field #boolean hasSkill True if the effect requires a skill parameter
-- @field #boolean onSelf True if the effect can be cast on self
-- @field #boolean onTouch True if the effect can be cast on touch
-- @field #boolean onTarget True if the effect can be cast on target
-- @field #boolean unreflectable True if the effect cannot be reflected
-- @field #boolean allowsSpellmaking True if the effect is available for spellmaking
-- @field #boolean allowsEnchanting True if the effect is available for enchanting
-- @field #boolean negativeLight True if the effect casts negative light
-- @field #number speed Projectile speed


---
-- @type MagicEffectWithParams
-- @field #MagicEffect effect @{#MagicEffect}
-- @field #string id ID of the associated @{#MagicEffect}
-- @field #string affectedSkill Optional skill ID
-- @field #string affectedAttribute Optional attribute ID
-- @field #number range
-- @field #number area
-- @field #number magnitudeMin
-- @field #number magnitudeMax
-- @field #number duration
-- @field #number index Index of this effect within the original list of @{#MagicEffectWithParams} of the spell/enchantment/potion this effect came from.

---
-- @type ActiveEffect
-- Magic effect that is currently active on an actor.
-- @field #string affectedSkill Optional skill ID
-- @field #string affectedAttribute Optional attribute ID
-- @field #string id Effect id string
-- @field #string name Localized name of the effect
-- @field #number magnitude Current magnitude of the effect. Will be set to 0 when the effect is removed or expires.
-- @field #number magnitudeBase
-- @field #number magnitudeModifier

--- @{#Sound}: Sounds and Speech. Not available in load scripts.
-- @field [parent=#core] #Sound sound

---
-- Checks if sound system is enabled (any functions to play sounds are no-ops when it is disabled).
-- It can not be enabled or disabled during runtime.
-- @function [parent=#Sound] isEnabled
-- @return #boolean
-- @usage local enabled = core.sound.isEnabled();

---
-- Play a 3D sound, attached to object
--
-- In local scripts can be used only on self.
-- @function [parent=#Sound] playSound3d
-- @param #string soundId ID of Sound record to play
-- @param #GameObject object Object to which we attach the sound
-- @param #table options An optional table with additional optional arguments. Can contain:
--
--   * `timeOffset` - a floating point number >= 0, to some time (in second) from beginning of sound file (default: 0);
--   * `volume` - a floating point number >= 0, to set a sound volume (default: 1);
--   * `pitch` - a floating point number >= 0, to set a sound pitch (default: 1);
--   * `loop` - a boolean, to set if sound should be repeated when it ends (default: false);
-- @usage local params = {
--    timeOffset=0.1,
--    volume=0.3,
--    loop=false,
--    pitch=1.0
-- };
-- core.sound.playSound3d("shock bolt", object, params)

---
-- Play a 3D sound file, attached to object
--
-- In local scripts can be used only on self.
-- @function [parent=#Sound] playSoundFile3d
-- @param #string fileName Path to sound file in VFS
-- @param #GameObject object Object to which we attach the sound
-- @param #table options An optional table with additional optional arguments. Can contain:
--
--   * `timeOffset` - a floating point number >= 0, to some time (in second) from beginning of sound file (default: 0);
--   * `volume` - a floating point number >= 0, to set a sound volume (default: 1);
--   * `pitch` - a floating point number >= 0, to set a sound pitch (default: 1);
--   * `loop` - a boolean, to set if sound should be repeated when it ends (default: false);
-- @usage local params = {
--    timeOffset=0.1,
--    volume=0.3,
--    loop=false,
--    pitch=1.0
-- };
-- core.sound.playSoundFile3d("Sound\\test.mp3", object, params)

---
-- Stop a 3D sound, attached to object
--
-- In local scripts can be used only on self.
-- @function [parent=#Sound] stopSound3d
-- @param #string soundId ID of Sound record to stop
-- @param #GameObject object Object on which we want to stop sound
-- @usage core.sound.stopSound("shock bolt", object);

---
-- Stop a 3D sound file, attached to object
--
-- In local scripts can be used only on self.
-- @function [parent=#Sound] stopSoundFile3d
-- @param #string fileName Path to sound file in VFS
-- @param #GameObject object Object on which we want to stop sound
-- @usage core.sound.stopSoundFile("Sound\\test.mp3", object);

---
-- Check if a sound is playing on the given object
-- @function [parent=#Sound] isSoundPlaying
-- @param #string soundId ID of Sound record to check
-- @param #GameObject object Object on which we want to check sound
-- @return #boolean
-- @usage local isPlaying = core.sound.isSoundPlaying("shock bolt", object);

---
-- Check if a sound file is playing on the given object
-- @function [parent=#Sound] isSoundFilePlaying
-- @param #string fileName Path to sound file in VFS
-- @param #GameObject object Object on which we want to check sound
-- @return #boolean
-- @usage local isPlaying = core.sound.isSoundFilePlaying("Sound\\test.mp3", object);

---
-- Play an animated voiceover.
-- In local scripts can be used only on self.
-- @function [parent=#Sound] say
-- @param #string fileName Path to sound file in VFS
-- @param #GameObject object Object on which we want to play an animated voiceover
-- @param #string text Subtitle text (optional)
-- @usage -- play voiceover for object and print messagebox
-- core.sound.say("Sound\\Vo\\Misc\\voice.mp3", object, "Subtitle text")
-- @usage -- play voiceover for object, without messagebox
-- core.sound.say("Sound\\Vo\\Misc\\voice.mp3", object)

---
-- Stop an animated voiceover
--
-- In local scripts can be used only on self.
-- @function [parent=#Sound] stopSay
-- @param #string fileName Path to sound file in VFS
-- @param #GameObject object Object on which we want to stop an animated voiceover
-- @usage core.sound.stopSay(object);

---
-- Check if an animated voiceover is playing
-- @function [parent=#Sound] isSayActive
-- @param #GameObject object Object on which we want to check an animated voiceover
-- @return #boolean
-- @usage local isActive = isSayActive(object);

---
-- @type SoundRecord
-- @field #string id Sound id
-- @field #string fileName Normalized path to sound file in VFS
-- @field #number volume Raw sound volume, from 0 to 255
-- @field #number minRange Raw minimal range value, from 0 to 255
-- @field #number maxRange Raw maximal range value, from 0 to 255

--- List of all @{#SoundRecord}s.
-- @field [parent=#Sound] #list<#SoundRecord> records A read-only list of all @{#SoundRecord}s in the world database, may be indexed by recordId.
-- Implements [iterables#List](iterables.html#List) of #SoundRecord.
-- @usage local sound = core.sound.records['Ashstorm']  -- get by id
-- @usage local sound = core.sound.records[1]  -- get by index
-- @usage -- Print all sound files paths
-- for _, sound in pairs(core.sound.records) do
--     print(sound.fileName)
-- end

--- @{#Stats}: stats. Not available in load scripts.
-- @field [parent=#core] #Stats stats


--- @{#Attribute} functions
-- @field [parent=#Stats] #Attribute Attribute

--- `core.stats.Attribute`
-- @type Attribute
-- @field #list<#AttributeRecord> records A read-only list of all @{#AttributeRecord}s in the world database, may be indexed by recordId.
-- Implements [iterables#List](iterables.html#List) of #AttributeRecord.
-- @usage local record = core.stats.Attribute.records['example_recordid']
-- @usage local record = core.stats.Attribute.records[1]

---
-- Returns a read-only @{#AttributeRecord}
-- @function [parent=#Attribute] record
-- @param #string recordId
-- @return #AttributeRecord

--- @{#Skill} functions
-- @field [parent=#Stats] #Skill Skill

--- `core.stats.Skill`
-- @type Skill
-- @field #list<#SkillRecord> records A read-only list of all @{#SkillRecord}s in the world database, may be indexed by recordId.
-- Implements [iterables#List](iterables.html#List) of #SkillRecord.
-- @usage local record = core.stats.Skill.records['example_recordid']
-- @usage local record = core.stats.Skill.records[1]

---
-- Returns a read-only @{#SkillRecord}
-- @function [parent=#Skill] record
-- @param #string recordId
-- @return #SkillRecord

---
-- @type AttributeRecord
-- @field #string id Record id
-- @field #string name Human-readable name
-- @field #string description Human-readable description
-- @field #string icon VFS path to the icon

---
-- @type SkillRecord
-- @field #string id Record id
-- @field #string name Human-readable name
-- @field #string description Human-readable description
-- @field #string icon VFS path to the icon
-- @field #string specialization Skill specialization. Either combat, magic, or stealth.
-- @field #MagicSchoolData school Optional magic school
-- @field #string attribute The id of the skill's governing attribute
-- @field #table skillGain Table of the 4 possible skill gain values. See [SkillProgression#SkillUseType](interface_skill_progression.html#SkillUseType).

---
-- @type MagicSchoolData
-- @field #string name Human-readable name
-- @field #string areaSound VFS path to the area sound
-- @field #string boltSound VFS path to the bolt sound
-- @field #string castSound VFS path to the cast sound
-- @field #string failureSound VFS path to the failure sound
-- @field #string hitSound VFS path to the hit sound

--- @{#Dialogue}: Dialogue. Not available in load scripts.
-- @field [parent=#core] #Dialogue dialogue

---
-- @{#DialogueRecords} functions for journal (quest) read-only records.
-- @field [parent=#Dialogue] journal
-- @usage --print the name of the record, which is a capitalized version of its id
-- print(core.dialogue.journal.records["ms_fargothring"].name) -- MS_FargothRing
-- @usage --print ids of all journal records
-- for _, journalRecord in pairs(core.dialogue.journal.records) do
--     print(journalRecord.id)
-- end
-- @usage --print quest names for all quests the player has inside a player script
-- for _, quest in pairs(types.Player.quests(self)) do
--     print(quest.id, core.dialogue.journal.records[quest.id].questName)
-- end

---
-- @{#DialogueRecords} functions for topic read-only records.
-- @field [parent=#Dialogue] topic
-- @usage --print ids of all topic records
-- for _, topicRecord in pairs(core.dialogue.topic.records) do
--     print(topicRecord.id)
-- end
-- @usage --print all NPC lines for "vivec"
-- for idx, topicInfo in pairs(core.dialogue.topic.records["vivec"].infos) do
--     print(idx, topicInfo.text)
-- end

---
-- @{#DialogueRecords} functions for voice read-only records.
-- @field [parent=#Dialogue] voice
-- @usage --print ids of all voice records
-- for _, voiceRecord in pairs(core.dialogue.voice.records) do
--     print(voiceRecord.id)
-- end
-- @usage --print all NPC lines & sounds for "flee"
-- for idx, voiceInfo in pairs(core.dialogue.voice.records["flee"].infos) do
--     print(idx, voiceInfo.text, voiceInfo.sound)
-- end

---
-- @{#DialogueRecords} functions for greeting read-only records.
-- @field [parent=#Dialogue] greeting
-- @usage --print ids of all greeting records
-- for _, greetingRecord in pairs(core.dialogue.greeting.records) do
--     print(greetingRecord.id)
-- end
-- @usage --print all NPC lines for "greeting 0"
-- for idx, greetingInfo in pairs(core.dialogue.greeting.records["greeting 0"].infos) do
--     print(idx, greetingInfo.text)
-- end

---
-- @{#DialogueRecords} functions for persuasion read-only records.
-- @field [parent=#Dialogue] persuasion
-- @usage --print ids of all persuasion records
-- for _, persuasionRecord in pairs(core.dialogue.persuasion.records) do
--     print(persuasionRecord.id)
-- end
-- @usage --print all NPC lines for "admire success"
-- for idx, persuasionInfo in pairs(core.dialogue.persuasion.records["admire success"].infos) do
--     print(idx, persuasionInfo.text)
-- end

---
-- A read-only list of all @{#DialogueRecord}s in the world database, may be indexed by recordId, which doesn't have to be lowercase.
-- Implements [iterables#List](iterables.html#list-iterable) of #DialogueRecord.
-- @field [parent=#DialogueRecords] #list<#DialogueRecord> records
-- @usage local record = core.dialogue.journal.records['ms_fargothring']
-- @usage local record = core.dialogue.journal.records['MS_FargothRing']
-- @usage local record = core.dialogue.journal.records[1]
-- @usage local record = core.dialogue.topic.records[1]
-- @usage local record = core.dialogue.topic.records['background']
-- @usage local record = core.dialogue.greeting.records[1]
-- @usage local record = core.dialogue.greeting.records['greeting 0']
-- @usage local record = core.dialogue.persuasion.records[1]
-- @usage local record = core.dialogue.persuasion.records['admire success']
-- @usage local record = core.dialogue.voice.records[1]
-- @usage local record = core.dialogue.voice.records["flee"]

---
-- Depending on which store this read-only dialogue record is from, it may either be a journal, topic, greeting, persuasion or voice.
-- @type DialogueRecord
-- @field #string id Record identifier
-- @field #string name Same as id, but with upper cases preserved.
-- @field #string questName Non-nil only for journal records with available value. Holds the quest name for this journal entry. Same info may be available under `infos[1].text` as well, but this variable is made for convenience.
-- @field #list<#DialogueRecordInfo> infos A read-only list containing all @{#DialogueRecordInfo}s for this record, in order.
-- @usage local journalId = core.dialogue.journal.records['A2_4_MiloGone'].id -- "a2_4_milogone"
-- @usage local journalName = core.dialogue.journal.records['A2_4_MiloGone'].name -- "A2_4_MiloGone"
-- @usage local questName = core.dialogue.journal.records['A2_4_MiloGone'].questName -- "Mehra Milo and the Lost Prophecies"

---
-- Holds the read-only data for one of many info entries inside a dialogue record. Depending on the type of the dialogue record (journal, topic, greeting, persuasion or voice), it could be, for example, a single journal entry or a NPC dialogue line.
-- @type DialogueRecordInfo
-- @field #string id Identifier for this info entry. Is unique only within the @{#DialogueRecord} it belongs to.
-- @field #string text Text associated with this info entry.
-- @usage --Variable `aa` below is "Congratulations, %PCName. You are now %PCName the %NextPCRank." in vanilla MW:
-- local aa = core.dialogue.topic.records['advancement'].infos[100].text
-- @usage --Variable `bb` below is "sound/vo/a/f/fle_af003.mp3" in vanilla MW:
-- local bb = core.dialogue.voice.records['flee'].infos[149].sound

---
-- Quest stage (same as in @{openmw_types#PLAYERQuest.stage}) this info entry is associated with.
-- Non-nil only for journal records.
-- @field [parent=#DialogueRecordInfo] #number questStage

---
-- True if this info entry has the "Finished" flag checked.
-- Non-nil only for journal records.
-- @field [parent=#DialogueRecordInfo] #boolean isQuestFinished

---
-- True if this info entry has the "Restart" flag checked.
-- Non-nil only for journal records.
-- @field [parent=#DialogueRecordInfo] #boolean isQuestRestart

---
-- True if this info entry has the "Quest Name" flag checked.
-- Non-nil only for journal records.
-- If true, then the @{#DialogueRecord}, to which this info entry belongs, should have this info entry's @{#DialogueRecordInfo.text} value available in its @{#DialogueRecord.questName}.
-- @field [parent=#DialogueRecordInfo] #boolean isQuestName

---
-- Faction of which the speaker must be a member for this info entry to appear.
-- Always nil for journal records. Otherwise the nil value represents no conditions, i.e. no filtering applied using these criteria.
-- Can return an empty string - this means that the actor must not be a member of any faction for this filtering to apply.
-- @field [parent=#DialogueRecordInfo] #string filterActorFaction

---
-- Speaker ID allowing for this info entry to appear.
-- Always nil for journal records. Otherwise the nil value represents no conditions, i.e. no filtering applied using these criteria.
-- @field [parent=#DialogueRecordInfo] #string filterActorId

---
-- Speaker race allowing for this info entry to appear.
-- Always nil for journal records. Otherwise the nil value represents no conditions, i.e. no filtering applied using these criteria.
-- @field [parent=#DialogueRecordInfo] #string filterActorRace

---
-- Speaker class allowing for this info entry to appear.
-- Always nil for journal records. Otherwise the nil value represents no conditions, i.e. no filtering applied using these criteria.
-- @field [parent=#DialogueRecordInfo] #string filterActorClass

---
-- Minimum speaker's rank in their faction allowing for this info entry to appear.
-- Always nil for journal records. Otherwise the nil value represents no conditions, i.e. no filtering applied using these criteria.
-- Rank index starts from 1, matching the value in @{openmw_types#NPC.getFactionRank}
-- @field [parent=#DialogueRecordInfo] #number filterActorFactionRank

---
-- Cell name prefix of location where the player must be for this info entry to appear.
-- Always nil for journal records. Otherwise the nil value represents no conditions, i.e. no filtering applied using these criteria.
-- "Prefix" means that the cell's name starting with this value shall pass the filtering. For example: `filterPlayerCell` being "Seyda Neen" does apply to the cell "Seyda Neen, Fargoth's House".
-- @field [parent=#DialogueRecordInfo] #string filterPlayerCell

---
-- Minimum speaker disposition allowing for this info entry to appear.
-- Always nil for journal records. Otherwise is a nonnegative number, with the zero value representing no conditions, i.e. no filtering applied using these criteria.
-- @field [parent=#DialogueRecordInfo] #number filterActorDisposition

---
-- Speaker gender allowing for this info entry to appear: "male" or "female".
-- Always nil for journal records. Otherwise the nil value represents no conditions, i.e. no filtering applied using these criteria.
-- @field [parent=#DialogueRecordInfo] #string filterActorGender

---
-- Faction of which the player must be a member for this info entry to appear.
-- Always nil for journal records. Otherwise the nil value represents no conditions, i.e. no filtering applied using these criteria.
-- @field [parent=#DialogueRecordInfo] #string filterPlayerFaction

---
-- Minimum player's rank in their faction allowing for this info entry to appear.
-- Always nil for journal records. Otherwise the nil value represents no conditions, i.e. no filtering applied using these criteria.
-- Rank index starts from 1, matching the value in @{openmw_types#NPC.getFactionRank}
-- @field [parent=#DialogueRecordInfo] #number filterPlayerFactionRank

---
-- Sound file path for this info entry.
-- Always nil for journal records or if there is no sound set.
-- @field [parent=#DialogueRecordInfo] #string sound

---
-- MWScript (full script text) executed when this info is chosen.
-- Always nil for journal records or if there is no value set.
-- @field [parent=#DialogueRecordInfo] #string resultScript

---
-- A read-only list of @{#DialogueInfoCondition}s.
-- Always nil for journal records.
-- @field [parent=#DialogueRecordInfo] #list<#DialogueInfoCondition> conditions

---
-- @type DialogueInfoCondition
-- @field #DialogueConditionOperator operator The #{#DialogueConditionOperator} to use in the comparison
-- @field #DialogueConditionType type The condition's @{#DialogueConditionType}
-- @field #number value The value to compare to
-- @field #string recordId The record ID to use in the comparison
-- @field #string variableName The name of the global or local mwscript variable to compare to
-- @field #string cellName The cell name to compare to

--- Possible @{#DialogueConditionOperator} values
-- @field [parent=#Dialogue] #DialogueConditionOperator CONDITION_OPERATOR

--- `core.dialogue.CONDITION_OPERATOR`
-- @type DialogueConditionOperator
-- @field #number Equal ==
-- @field #number NotEqual !=
-- @field #number Greater >
-- @field #number GreaterEqual >=
-- @field #number Less <
-- @field #number LessEqual <=

--- Possible @{#DialogueConditionType} values
-- @field [parent=#Dialogue] #DialogueConditionType CONDITION_TYPE

--- `core.dialogue.CONDITION_TYPE`
-- @type DialogueConditionType
-- @field #number FacReactionLowest Lowest faction reaction from the speaker's primary faction to the player's factions
-- @field #number FacReactionHighest Highest faction reaction from the speaker's primary faction to the player's factions
-- @field #number RankRequirement Check whether the player can advance in the speaker's primary faction
-- @field #number Reputation The speaker's reputation
-- @field #number HealthPercent The speaker's health percentage
-- @field #number PcReputation The player's reputation
-- @field #number PcLevel The player's level
-- @field #number PcHealthPercent The player's health percentage
-- @field #number PcMagicka The player's current magicka
-- @field #number PcFatigue The player's current fatigue
-- @field #number PcStrength The player's current strength
-- @field #number PcBlock The player's current block
-- @field #number PcArmorer The player's current armorer
-- @field #number PcMediumArmor The player's current medium armor
-- @field #number PcHeavyArmor The player's current heavy armor
-- @field #number PcBluntWeapon The player's current blunt weapon
-- @field #number PcLongBlade The player's current long blade
-- @field #number PcAxe The player's current axe
-- @field #number PcSpear The player's current spear
-- @field #number PcAthletics The player's current athletics
-- @field #number PcEnchant The player's current enchant
-- @field #number PcDestruction The player's current destruction
-- @field #number PcAlteration The player's current alteration
-- @field #number PcIllusion The player's current illusion
-- @field #number PcConjuration The player's current conjuration
-- @field #number PcMysticism The player's current mysticism
-- @field #number PcRestoration The player's current restoration
-- @field #number PcAlchemy The player's current alchemy
-- @field #number PcUnarmored The player's current unarmored
-- @field #number PcSecurity The player's current security
-- @field #number PcSneak The player's current sneak
-- @field #number PcAcrobatics The player's current acrobatics
-- @field #number PcLightArmor The player's current light armor
-- @field #number PcShortBlade The player's current short blade
-- @field #number PcMarksman The player's current marksman
-- @field #number PcMercantile The player's current mercantile
-- @field #number PcSpeechcraft The player's current speechcraft
-- @field #number PcHandToHand The player's current hand to hand
-- @field #number PcGender The player's gender
-- @field #number PcExpelled Check whether the player has been expelled from the speaker's primary faction
-- @field #number PcCommonDisease Check if the player has a common disease
-- @field #number PcBlightDisease Check if the player has a blight disease
-- @field #number PcClothingModifier Check the combined value of the player's outfit
-- @field #number PcCrimeLevel The player's bounty
-- @field #number SameGender Check if the speaker's gender matches the player's
-- @field #number SameRace Check if the speaker's race matches the player's
-- @field #number SameFaction Check if the player is a member of the speaker's primary faction
-- @field #number FactionRankDifference The difference between the player's rank in the speaker's primary faction and the speaker's
-- @field #number Detected Whether the speaker has detected the player
-- @field #number Alarmed Whether the speaker was alarmed by the player's crime
-- @field #number Choice The choice index
-- @field #number PcIntelligence The player's current intelligence
-- @field #number PcWillpower The player's current willpower
-- @field #number PcAgility The player's current agility
-- @field #number PcSpeed The player's current speed
-- @field #number PcEndurance The player's current endurance
-- @field #number PcPersonality The player's current personality
-- @field #number PcLuck The player's current luck
-- @field #number PcCorprus Whether the player is affected by the Corprus magic effect
-- @field #number Weather Checks the scriptId of the weather in the player's cell
-- @field #number PcVampire Whether the player is affected by the Vampirism magic effect
-- @field #number Level The speaker's level
-- @field #number Attacked Whether the speaker was attacked
-- @field #number TalkedToPc Whether the speaker has talked to the player before
-- @field #number PcHealth The player's current health
-- @field #number CreatureTarget Whether the speaker is targeting a creature
-- @field #number FriendHit The number of times the player has hit the speaker follower
-- @field #number Fight The speaker's current fight
-- @field #number Hello The speaker's current hello
-- @field #number Alarm The speaker's current alarm
-- @field #number Flee The speaker's current flee
-- @field #number ShouldAttack Whether the speaker would start combat with the player
-- @field #number Werewolf Whether the speaker is in werewolf form
-- @field #number PcWerewolfKills The number of werewolves killed by the player
-- @field #number Global A comparison to the @{#DialogueInfoCondition.variableName} global variable
-- @field #number Local A comparison to the speaker's @{#DialogueInfoCondition.variableName} local variable
-- @field #number Journal A comparison to the player's @{#DialogueInfoCondition.recordId} journal index
-- @field #number Item The number of copies of @{#DialogueInfoCondition.recordId} the player is carrying
-- @field #number Dead The number of dead actors of the given @{#DialogueInfoCondition.recordId}
-- @field #number NotId The speaker's recordId should not match @{#DialogueInfoCondition.recordId}
-- @field #number NotFaction The speaker's faction ID should not match @{#DialogueInfoCondition.recordId}
-- @field #number NotClass The speaker's class should not match @{#DialogueInfoCondition.recordId}
-- @field #number NotRace The speaker's race should not match @{#DialogueInfoCondition.recordId}
-- @field #number NotCell The player's cell name should not start with @{#DialogueInfoCondition.cellName}
-- @field #number NotLocal A comparison to the speaker's @{#DialogueInfoCondition.variableName} local variable

--- @{#Regions}: Regions. Not available in load scripts.
-- @field [parent=#core] #Regions regions

---
-- A read-only list of all @{#RegionRecord}s in the world database.
-- @field [parent=#Regions] #list<#RegionRecord> records
-- @usage local record = core.regions.records['bitter coast region']
-- @usage local record = core.regions.records[1]

---
-- Region data record
-- @type RegionRecord
-- @field #string id Region ID
-- @field #string name Region display name
-- @field openmw.util#Color mapColor Editor map color for this region.
-- @field #string sleepList A leveled creature list used when sleeping outdoors in this region
-- @field #list<#RegionSoundRef> sounds A read-only list of ambient sound references for this region.
-- Each reference includes a chance and a resolved link to the full sound record.
-- @field #table weatherProbabilities A table mapping @{#WeatherRecord.recordId}s to their probability (0–100), should sum to 100.
-- Valid weather ids include:
--   `"clear"`, `"cloudy"`, `"foggy"`, `"overcast"`, `"rain"`, `"thunderstorm"`, `"ashstorm"`, `"blight"`, `"snow"`, `"blizzard"`
-- @usage print(region.weatherProbabilities["rain"])

---
-- Region sound reference
-- @type RegionSoundRef
-- @field #string soundId Sound record ID
-- @field #number chance Multiplicative percentage used to determine whether to play the sound

--- @{#Factions}: Factions. Not available in load scripts.
-- @field [parent=#core] #Factions factions

---
-- A read-only list of all @{#FactionRecord}s in the world database.
-- @field [parent=#Factions] #list<#FactionRecord> records
-- @usage local record = core.factions.records['example_recordid']
-- @usage local record = core.factions.records[1]

---
-- Faction data record
-- @type FactionRecord
-- @field #string id Faction id
-- @field #string name Faction name
-- @field #list<#FactionRank> ranks A read-only list containing data for all ranks in the faction, in order.
-- @field #map<#string, #number> reactions A read-only map containing reactions of other factions to this faction.
-- @field #list<#string> attributes A read-only list containing IDs of attributes to advance ranks in the faction.
-- @field #list<#string> skills A read-only list containing IDs of skills to advance ranks in the faction.
-- @field #boolean hidden If true, the faction won't show in the player's skills menu

---
-- Faction rank data record
-- @type FactionRank
-- @field #string name Faction name Rank display name
-- @field #list<#number> attributeValues Attributes values required to get this rank.
-- @field #number primarySkillValue Primary skill value required to get this rank.
-- @field #number favouredSkillValue Secondary skill value required to get this rank.
-- @field #number factionReputation Required amount of faction reputation to reach this rank.
-- @field #number factionReaction (DEPRECATED) Returns the same as factionReputation.

--- @{#MWScripts}: MWScripts. Not available in load scripts.
-- @field [parent=#core] #MWScript mwscripts

---
-- A read-only list of all @{#MWScriptRecord}s in the world database.
-- @field [parent=#MWScripts] #list<#MWScriptRecord> records
-- @usage local record = core.mwscripts.records['example_recordid']
-- @usage local record = core.mwscripts.records[1]

---
-- MWScript data record
-- @type MWScriptRecord
-- @field #string id MWScript id
-- @field #string text MWScript content


--- @{#Weather}: Weather. Not available in load scripts.
-- @field [parent=#core] #Weather weather

--- List of all @{#WeatherRecord}s.
-- @field [parent=#Weather] #list<#WeatherRecord> records A read-only list of all @{#WeatherRecord}s in the world database, may be indexed by recordId.
-- Implements [iterables#List](iterables.html#List) of #WeatherRecord.
-- @usage local weather = core.weather.records['Cloudy']  -- get by id
-- @usage local weather = core.weather.records[1]  -- get by index
-- @usage -- Print all storms
-- for _, weather in pairs(core.weather.records) do
--     if weather.isStorm then
--         print(weather.name)
--     end
-- end

---
-- Get the current weather
-- @function [parent=#Weather] getCurrent
-- @param #Cell cell The cell to get the current weather for
-- @return #WeatherRecord Can be nil if the cell is inactive or has no weather

---
-- Get the next weather if any
-- @function [parent=#Weather] getNext
-- @param #Cell cell The cell to get the next weather for
-- @return #WeatherRecord Can be nil

---
-- Get current weather transition value
-- @function [parent=#Weather] getTransition
-- @param #Cell cell The cell to get the transition value for
-- @return #number Can be nil if the cell is inactive or has no weather

---
-- Change the weather
-- @function [parent=#Weather] changeWeather
-- @param #string regionId
-- @param #WeatherRecord weather The weather to change to

---
-- Get the current direction of the light of the sun.
-- @function [parent=#Weather] getCurrentSunLightDirection
-- @param #Cell cell The cell to get the sun direction for
-- @return openmw.util#Vector4 Can be nil if the cell is inactive

---
-- Get the current sun visibility taking weather transition into account.
-- @function [parent=#Weather] getCurrentSunVisibility
-- @param #Cell cell The cell to get the sun visibility for
-- @return #number Can be nil if the cell is inactive or has no weather

---
-- Get the current sun percentage taking weather transition into account.
-- @function [parent=#Weather] getCurrentSunPercentage
-- @param #Cell cell The cell to get the sun percentage for
-- @return #number Can be nil if the cell is inactive or has no weather

---
-- Get the current wind speed taking weather transition into account.
-- @function [parent=#Weather] getCurrentWindSpeed
-- @param #Cell cell The cell to get the wind speed for
-- @return #number Can be nil if the cell is inactive or has no weather

---
-- Get the current storm direction taking weather transition into account.
-- @function [parent=#Weather] getCurrentStormDirection
-- @param #Cell cell The cell to get the storm direction for
-- @return openmw.util#Vector3 Can be nil if the cell is inactive or has no weather

---
-- Weather data
-- @type WeatherRecord
-- @field #string recordId
-- @field #number scriptId Read-only ID used in mwscript and dialogue
-- @field #string name Read-only weather name
-- @field #number windSpeed Affects the angle of falling rain
-- @field #number cloudSpeed
-- @field #string cloudTexture
-- @field #number cloudsMaximumPercent Affects the speed of weather transitions (0, 1]
-- @field #boolean isStorm Controls whether the weather is considered a storm for animation and movement purposes
-- @field openmw.util#Vector3 stormDirection
-- @field #number glareView Strength of the sun glare [0, 1]
-- @field #number rainSpeed The speed at which rain falls
-- @field #number rainEntranceSpeed The number of seconds between rain particle batches being created
-- @field #string rainEffect Will return nil if weather has no rainEffect
-- @field #number rainMaxRaindrops The maximum number of rain particle batches to create every rainEntranceSpeed
-- @field #number rainDiameter The area around the player to spawn rain in
-- @field #number rainMaxHeight The maximum height relative to the player to spawn rain at
-- @field #number rainMinHeight The minimum height relative to the player to spawn rain at
-- @field #string rainLoopSoundID
-- @field #table thunderSoundID A read-only array containing the recordIds of the thunder sounds
-- @field #string ambientLoopSoundID
-- @field #string particleEffect Will return nil if weather has no particleEffect
-- @field #number distantLandFogFactor
-- @field #number distantLandFogOffset
-- @field openmw.util#Color sunDiscSunsetColor
-- @field #TimeOfDayInterpolatorFloat landFogDepth
-- @field #TimeOfDayInterpolatorColor skyColor
-- @field #TimeOfDayInterpolatorColor ambientColor
-- @field #TimeOfDayInterpolatorColor fogColor
-- @field #TimeOfDayInterpolatorColor sunColor

---
-- Interpolates numbers for weathers based on time of day
-- @type TimeOfDayInterpolatorFloat
-- @field #number sunrise
-- @field #number sunset
-- @field #number day
-- @field #number night

---
-- Interpolates colors for weathers based on time of day
-- @type TimeOfDayInterpolatorColor
-- @field openmw.util#Color sunrise
-- @field openmw.util#Color sunset
-- @field openmw.util#Color day
-- @field openmw.util#Color night

return nil
